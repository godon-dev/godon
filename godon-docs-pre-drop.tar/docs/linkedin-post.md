# LinkedIn feed post — paper 1 announcement (final, Aug 19 2026)

Feed post (not Article). First line = title. Image: fig2 sensitivity crop
(/tmp/godon-post-fig2-sensitivity.png). Doctrine: shipped claims only,
boundary stated, Z.ai in body not title, beacon close.

---

First paper out from godon-dev: The Impulse Protocol — non-destructive coupling discovery in autonomous agents.

https://doi.org/10.5281/zenodo.21962957

The problem it addresses: when several autonomous agents work on the same live system, they influence each other through coupling channels that no log, metric, or model contains. Passive observation cannot separate coupling from coincidence — the structure shows only in response to intervention.

The protocol makes that intervention safe and explicit: one agent pushes parameters it already controls to guardrail-bounded extremes, the others hold still, and a CFAR step-change detector (radar lineage) tests each receiver for a shift that reverses when the push ends. The stance is old — Ashby's black-box methodology, made runnable: intervene, observe, reverse. Bench results with planted ground truth: zero false positives across the whole sweep, a 4-node topology recovered exactly, edge strengths measured within ~10%, multi-hop prediction within 9% in the linear case. Limits are stated in the paper, not hidden.

Behind the paper is godon-dev, an independent open-source project (AGPLv3). Its premise: the agents already tuning a live system become, when coordinated, the instrument that measures its hidden structure — and the instrument serves a longer aim: structure measured, then tended, then steered. Code public: github.com/godon-dev. The work behind the paper — the code, the experiments, the writing, and the vision driving them — was endeavored together with Z.ai models.

Where this is heading: characterization (full response curves per measured edge) and composition (how far measured edges predict system-wide response) are in workings now — the next steps toward that aim.

This is early, and the interesting problems are open. If you work on signal detection, causal discovery, control theory, experiment design, or multi-agent systems — or run coupled systems whose structure you can't see — reach out. Feedback welcome, especially on the detection statistics and the composition problem.
