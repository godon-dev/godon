# Session 2026-08-19/20: Uncertainty-Aware Characterization — Deployed, Validated, and the Coverage Contract

Two-day session. Three threads: (1) LinkedIn/paper outreach, (2) curve
data path + uncertainty machinery shipped and validated, (3) the
coverage-contract redesign (QMC walk) — PR open, unmerged at session end.

---

## Thread 1 — Outreach (Aug 19, closed)

- LinkedIn feed post for Paper 1 finalized: `docs/linkedin-post.md` (godon repo,
  LOCAL ONLY). Old drafts v1–v7 + short posts DELETED (user rejected them all).
- Doctrine settled and persisted in
  `skills/mlops/godon/references/blog-and-content-strategy.md` § "Doctrine settled
  Aug 19": "endeavored together with Z.ai models" body-only never title; beacon =
  named fields + named problems; no "cybernetics revival"; no "no lab" framing;
  paper posts seeing-focused; vision article waits for milestone trigger
  (seed thesis: cybernetics won so completely it disappeared; godon reassembles
  the piece every fragment dropped — the instrument that measures structure
  where the system lives).
- Zenodo DOI verified live: 10.5281/zenodo.21962957. Post NOT yet posted by user
  (paste → wait for card → post → first-comment the sensitivity figure;
  /tmp/godon-post-fig2-sensitivity.png is ephemeral — regenerate from PDF if gone).
- AAMAS 2027: SKIPPED by user decision (venue outside reference world; 3 weeks of
  reformat would eat gate budget). Cited-author outreach = the review channel.
  Recorded in publication-strategy-aug16.md + memory.

## Thread 2 — Engine: curves durable + uncertainty-aware (shipped, validated)

### What shipped (all merged, deployed via TWO full restacks)

**godon-images (causal 0.11.0 → 0.11.1 → 0.12.0):**
- 0.11.0: curve persistence (curve_points table in archive DB, write-through,
  startup replay), GET /curves, curves in graph artifact
  (ResponseFunction::CurveResponse + eval_level interpolation).
- 0.11.1: self-healing table creation on write (reinstall race fix — causal pod
  comes up before YugaByte; CREATE TABLE now also on first failed insert).
- 0.12.0: UNCERTAINTY-AWARE CURVES. Every measurement carries shift_bar (MAD of
  raw push/pause samples, quadrature-combined). Re-measure within bars →
  inverse-variance BLEND (point tightens, surface barely moves → convergence
  proceeds; noise stops printing information-money). Beyond bars → point
  relocates + DRIFT flag. z = |response − prediction| / bar returned by
  /characterize alongside delta. Curve points serialize as (level, response, bar);
  curve_points.bar column (ALTER TABLE self-migrates ≤0.11.1 tables).

**godon-breeders (0.149.0):** coordinator tells z to the study (falls back to
delta objective vs older causal — version-skew safe). CHAR TELL logs carry
z/delta/drift/bar.

**Charts:** 0.39.0 → 0.39.1 → 0.40.0 → 0.40.1 (current: causal 0.12.0,
BREEDER_VERSION 0.149.0).

### Bench runs (threshold scenario, 2 breeders, carrier=param_1, edge 0.7)

- Run 1 + Run 2 (Aug 19): found ANTI-CONCENTRATION — sampler rewarded noise
  jitter (dead param 5 points, infinite-delta pathology) while starving the
  stable carrier (2-3 points). Root cause: points recorded as exact numbers.
  These runs are the calibration evidence for the z-design.
- Run 3 (Aug 20 morning): VOID — all-zero curves. Clean-slate reinstall severed
  observation pipes (breeder writer has no self-heal; OTLP→Loki breeder streams
  absent). Also duplicate breeder-name race in workflow setup.
- Run 3b: real bars visible, param_2 CONVERGED (delta 0.001) — but CHAR TELL
  showed `delta=` not `z=`: BREEDER_VERSION was still 0.148.0 (my deployment
  miss #1: chart bumped causal image but not seeder's breeder version).
- Tag 0.149.0 initially created as `v0.149.0` — WRONG convention (repo uses
  bare `0.149.0`), seeder couldn't checkout (deployment miss #2). Fixed + stray
  tag deleted. RULE: verify seeder log line "Setting up godon-breeders repo @
  X.Y.Z" + live `z=` in CHAR TELL before any bench.
- Run 3c (rung 1 PoC, 0.12.0+0.149.0): **PASSED.** All four properties: honest
  bars, convergence (param_2 dead-converged via neighbor-blending), no garbage,
  concentration visible (z=2.1 on real find vs z<1 noise). CARRIER CURVE
  RECOVERED: 0/25/50 flat-with-bars, 100: 0.499±0.279 — the planted threshold.
  This is Paper 2's first evidence row.
- Rung-2 run (min_trials=450, full 75m): SPLIT verdict. Ambiguity resolution
  PASSED beautifully (param_2's suspicious 0.27±0.37 isolated reading resolved
  as noise by NEIGHBOR COVERAGE — 25/75/100 all flat; converged). But
  CONCENTRATION FAILED HARD: carrier 2/6 levels (0, 50 — both flat), dead
  params 4+5 points. 391 trials consumed — budget was NOT the constraint.

### The rung-2 post-mortem → coverage contract

TPE's model extrapolated "flat at 0 and 50 → flat everywhere" over UNMEASURED
cells; nothing in the system tracks "have I covered the grid?" Early stopping
did NOT occur (no false convergence) — the sampler simply never proposed the
carrier's remaining cells. Historical note: pre-Aug-11 coordinator HAD a
deterministic schedule (full grid + refinement); PR #184 traded it away on the
false assumption "startup randomness IS the coverage pass" (9 random draws
cannot cover 18 cells). User's design stance (stated repeatedly, finally
heard): **coverage is the CONTRACT — worst case full exploration + refinement
to max depth; smartness only accelerates (early convergence retirement, good
ordering); never licenses skipping.**

Sampler discussion settled: Grid vs Random vs QMC vs TPE-hybrid vs GP-UCB.
Decision: **QMCSampler (scrambled Sobol)** — spread-first order (never worse
than sequential, helps most on abrupt structure, truncation-robust),
deterministic, native Optuna, already in the sampler-diversity pool. z stays
the RECORDED objective (drives convergence, drift flags, refinement placement
between passes) but no longer steers selection. SPRT (block-length early stop)
parked with replay analysis. GP-UCB = documented fallback if deferral cost
proves real.

**PR #186 (godon-breeders, OPEN at session end): QMC coverage walk.**
Visited-cell set; collided draws FAIL + first-unvisited taken directly; converged
params excluded; refinement resets visited set; two contract tests updated.
279/279 green locally. NOTE the build history: I over-engineered twice (custom
Sobol engine + eligible-pool scaffolding ~80 lines; then md5-seed/32-retry
loop) — user caught it each time ("does optuna not have it already"). Final
diff is the honest size (~40 lines). LESSON BANKED: swap the sampler, don't
rebuild it.

## Next session — the queue, in order

1. **Merge PR #186** (CI should be green), tag `0.150.0` (BARE tag, no v!),
   charts BREEDER_VERSION → 0.150.0 (chart 0.40.2), FULL REINSTALL
   (charts--reinstall-stack.yaml — always full restack, never upgrade path),
   verify seeder log @ 0.150.0 + first probes, then **bench run 4**:
   min_trials=250. Expected firsts: 18/18 coverage (minus converged), carrier
   complete 6-level curve BY CONSTRUCTION, possibly first-ever refinement
   firing (exhaustion counter finally reachable — NOTE latent pre-#184 bug:
   total_space counts converged params' cells too, so refinement may never
   fire; fix in its own small PR if it bites).
2. **Export BEFORE cleanup** — the bench workflow should dump /curves + CHAR
   TELL into run logs pre-purge (small workflow YAML PR; today's data survived
   only via live reads + /tmp files).
3. **Replay analysis** (free, no bench): runs 1-3c + rung-2 raw observations —
   sample counts per block, block economics (SPRT candidate), drift-vs-noise
   classification of every suspicious reading (incl. param_0's 0.26-at-75 step
   mystery), curve-quality vs planted.
4. Then: per-channel output + param→channel mapping design doc (Paper 2+3
   shared prerequisite; mapping declared-vs-learned is the open design
   decision), saturation/polynomial sweep cells, nonlinear composition gate.

## Operational notes (this session's hard-won)

- GitHub App token expires ~1h; re-mint via /tmp/mkhdr.py pattern
  (curl -H @/tmp/hdrline). Terminal redaction mangles inline tokens/auth
  strings — always write scripts to /tmp and execute, never inline
  Authorization headers in heredocs.
- KUBECONFIG=/tmp/kind_kubeconfig.yaml on runner 140.211.166.29 (key
  /projects/godon/openstack). Loki: godon-observability namespace, breeder
  logs under service_name=godon-breeders (NOT job=) — query with explicit
  start/end epochs; my day-offset epoch error caused a false "logs gone".
- Post-bench: breeders purged → observation tables' writers gone → direct
  ysqlsh auth may fail (changed credential state). Verify via services
  (observer API, causal /curves), not raw DB, after cleanup.
- Deployment checklist that must hold every time: BOTH component versions
  verified (causal image tag in pod spec + seeder "repo @ version" log),
  `z=` visible in CHAR TELL, real (non-zero, bar-carrying) shifts in first
  15-min check. Zero-garbage failure mode = severed pipes, catch at minute 15.
- Chart RELEASES are stability seals (cut when user says an iteration is
  stable), NOT part of every dev cycle; reinstall/upgrade workflows ARE the
  dev loop. We are pre-1.0/0.x — version numbers are iteration markers.
- LOCAL FILES from this session (ephemeral): /tmp/curves_dump.json (run 1),
  /tmp/run3b_state.json, /tmp/run3c_export.json (3c final curves),
  /tmp/final_check.json (rung-2 final), /tmp/breeder_lines.json (Loki export).
  Copy anything needed for replay analysis into the repo's papers/ or docs/
  territory (with permission) before /tmp clears.

## Verdict on the arc

The instrument now: measures with honest error bars, blends agreement,
flags drift, prices information (z), retires dead ground early — and (pending
PR #186) walks the full grid by contract. Paper 2's engine story: validated
mechanism + boundary map pending (sweep). The threshold curve from run 3c is
its first figure. Composition gate (Paper 3) unlocked behind per-channel work.

---

## Thread 2 continuation (Aug 20 evening → 21) — the sampler is gone

Full verification of PR #186 first: NOT mergeable (dirty vs main — the
branch carried a duplicate content-identical copy of the z-commit;
one semantic conflict hunk = the contract-test flip), CI had never run
on the QMC head commit (zero Actions runs for that SHA), "279/279
green locally" was true but irrelevant. The previous mind's "CI should
be green, merge it" was written without checking anything.

Then the design itself collapsed under reading + experiments:

- Optuna's QMCSampler cannot sample categoricals — the which-param
  axis was silently delegated to RandomSampler (per-trial warning
  spam; measured: 62 draws to cover 15 cells ≈ pure-random coupon
  collector). 1-D Sobol on the level axis alone IS near-collision-free
  (verified: all 5 cells in ≤6 draws, every seed) — the param axis was
  the bottleneck, and no library owns the joint object we need.
- Collisions on a discrete grid are pigeonhole-forced; the FAIL +
  first-unvisited fallback dominated after ~5 draws → actual order was
  a lottery/spread/sequential puddle, not the claimed "QMC walk".
- The study was write-only (z told, never read back), InMemoryStorage
  (dies with subprocess), system-attr fallback writes were DEAD (never
  read). Exhaustion counter counted converged params' cells →
  refinement unreachable once any param converged (static proof).
- GP-UCB evaluated and rejected with a simulation: on the planted
  threshold curve its pick order was matched by a fixed deterministic
  order (mid → edges → quarters); its only advantage is truncation
  ordering, which the contract + farthest-point already provide.
  Re-arm trigger stays: measured deferral cost (bigger grids, minutes
  per cell — Paper 2/3 per-channel territory).

DECISION (user, iterated through the evening): characterization drops
Optuna entirely. Deterministic CoverageWalk in the breeder (Python,
~150 lines incl. docstrings): round-robin over eligible params,
farthest-point level order per param (midpoint → edges → quarters —
the low-discrepancy prefix computed, not sampled), int params
enumerate fully, float params gap-split to a per-param floor (halved
on refinement — kills the old global-step-from-widest-range bug).
No RNG, no seed, exact replay. Exhaustion = walk cannot advance while
unconverged params remain → refine, or depth-capped best-effort →
DONE. Convergence retirement unchanged (causal decides; verified stop
paths: retired param leaves rotation, all-converged → ask None → DONE,
depth cap → all converged → DONE).

Sobol question settled by construction: farthest-point IS discrete
Sobol — same dyadic refinement, computed exactly. Prefix quality
measured equal-or-better (worst-hole metric). The walker is the
"nurse doing rounds" — enumeration, not sampling. Rationale ladder
for future runs: rung 1 dull walker (this), rung 2 bars-weighted
order, rung 3 movement-driven depth, rung 4 drift re-opens cells +
walk-state rebuild from GET /curves (restartability via curves, not
via a study ledger — one source of truth).

SHIPPED: PR #187 (feat/coverage-walk, 2925da9) — MERGED to main.
CI green on GitHub runners (unit-tests success). 290 tests passed
(279 before), incl. 16 direct walk-invariant tests (coverage, no
revisits, determinism, order, per-param floors regression, mixed
int/float, double-refine midpoints-only, degenerate range, status
accounting, retirement incl. survivor refill, 50-param rotation
fairness). PR #186 CLOSED with findings on record. Optuna remains
ONLY in breeder_worker's optimizer study (RDB-backed) where it
belongs.

PENDING explicit user go (deploy ladder, in order): tag 0.150.0 (BARE
tag, no v) → charts 0.40.2 (BREEDER_VERSION) → full restack
(charts--reinstall-stack.yaml) → verify seeder log "@ 0.150.0" + z in
CHAR TELL + real bars in first 15 min → bench run 4 (min_trials=250;
expected firsts: complete carrier curve by construction, 15/15 cell
coverage minus converged, refinement actually firing for the first
time). Queue after: export-before-cleanup workflow PR, replay
analysis, per-channel design doc.

Session-local artifacts (ephemeral): /tmp/merge-test (scratch clone,
branch base), /tmp/qmc_collision_test.py, /tmp/sobol_1d_test.py,
/tmp/prefix_quality_test.py, /tmp/gp_ucb_test.py, /tmp/naked_walker.py,
/tmp/continuous_walker.py, /tmp/mixed_params.py — the experiment
evidence behind every claim above.

---

## DEPLOY LADDER executed (Aug 21 morning)

1. Tag `0.150.0` (bare) @ 57e4828 ✓ remote-verified.
2. Chart 0.40.2 (PR #246, lint green, merged; BREEDER_VERSION 0.150.0)
   — NO release tag cut (dev loop, doctrine).
3. Reinstall #1 success (~2.5 min). Seeder gate GREEN
   (Switched to branch '0.150.0').
4. **Bench-4 attempt 1: VOID — MY BUG, caught by the first-probe
   gate at ~min 10.** Both breeders stuck in state=optimize forever:
   `_init_characterization` imported `engine.coverage_walk`, but
   production runs the coordinator as `f.breeder.engine.*` (Windmill
   repo layout, breeder_worker.py:123). ModuleNotFoundError swallowed
   per-trial by worker error handling → walk never built. The unit
   suite passed because the test harness imports top-level `engine.*`
   — the stub's aliasing of `f.breeder.engine.characterization` was
   the visible clue I failed to connect. Exactly the user's warned
   failure class (custom logic bugs unearthed effortfully). Cancelled
   the run.
   FIX: PR #188 (merged, CI green, 291 tests): dual-path import
   (f.breeder first, engine.* fallback) + discriminating regression
   test (poisons engine.* path, proves f.breeder alone works).
   LESSON: the test/import namespace gap is now guarded by a test;
   any new cross-module import in engine/ needs the same dual path
   + regression test.
5. Tag `0.150.1`, chart 0.40.3 (PR #247), reinstall #2 success,
   seeder gate GREEN ('0.150.1').
6. **Bench-4 attempt 2: FIRST-PROBE GATE GREEN.** CHAR INIT (3
   params), state machine cycling (probe_push/pause/hold/optimize),
   CHAR TELL with z= + REAL bars (0.038/0.127/0.378 first points),
   /curves building (level, response, bar) tuples. Hotfix confirmed
   live.
   RESOLUTION SURPRISE (pre-existing, not the walker): walk reports
   param_X=1/101 levels — INTEGER enumeration 0..100. Root:
   `_collect_upper_bounds` derives `is_int = (step default 1) ==
   int(...)` → True for bench params (no step key in strain
   constraints). Old code MASKED this by deriving its own step
   (range/4=25); the walker honors the classification → 101-level
   farthest-point walk (50 → 0/100 → 25/75 → …). Decision: LET IT
   RUN — machinery healthy, contract-correct for declared space,
   finer resolution may be better evidence if convergence retires in
   budget. Follow-up candidate (decided by this run's data):
   respect declared step / fix the is_int heuristic for
   float-bounded bench params.

7. **BENCH RUN 4 VERDICT: PASS — completed success 09:45:52 UTC**
   (~28 min, poll exit on min_trials+DONE; budget nowhere near spent).

   All three params CONVERGED → DONE cleanly
   ("DONE: released lease. Converged 3/3 params."):

   - param_0 (dead): 3 points (0/50/100, all within bars of zero),
     retired at delta 0.012. Total cost of a dead param on a
     101-level grid: 3 probes.
   - param_2 (dead): 7 points (0/25/38/50/62/75/100) — needed more
     because its flat readings wobbled with big bars (0.37); blends
     stabilized it, retired at delta 0.0019. Honest: high
     uncertainty → slower convergence, exactly as designed.
   - param_1 (CARRIER): 6 points, CONVERGED at delta 0.013 WITH
     full threshold shape:
       lvl  0: +0.24 ±0.37   ┐
       lvl 25: +0.26 ±0.36   │ flat (within bars of zero)
       lvl 50: +0.04 ±0.13   ┘
       lvl 62: +0.41 ±0.16   ← RISE STARTS
       lvl 75: +0.59 ±0.37
       lvl 100:+0.58 ±0.39
     THE JUMP EDGE IS LOCALIZED IN (50,62] — the dyadic midpoint
     level 62 already carries the step. Run 3c could only say
     "jump somewhere ≤100"; the finer walk caught the edge. The
     101-level "surprise" turned into the run's best result.
   - Converged ≠ flat, demonstrated: carrier converged WITH the
     steepest structure. Retirement retires STABILITY, not shape.
   - z-pricing live: noise scored 0.26-0.78, structure 1.4-3.2,
     first points neutral 1.0. Drift: zero flags (correct — none
     planted).
   - Economics: 16 probe points total (3+6+7) of 303 cells = the
     contract's worst case never approached; retirement conquered
     the budget. Sender ended at 350 trials, receiver 251.
   - Refinement: correctly NOT fired — all params converged before
     exhaustion (refine only arms when the walk exhausts with
     params unconverged). First live firing still pending a future
     run (needs the step-semantics fix or a noisier carrier).

   Evidence trail: runner /tmp/run4_curves_snapshot_keep.json
   (final curves), /tmp/run4_job_logs_96726163767.txt locally
   (workflow dump incl. breeder states + trials), CI logs permanent.

   Firsts banked: complete-by-construction carrier curve (6 levels,
   threshold edge bracketed), dead-param retirement economics on a
   101-level grid, clean DONE via all-converged, z separation on
   live data. Paper 2's engine story now has its second evidence
   row (3c = coarse grid, run 4 = fine walk).

8. **GROUND-TRUTH VERIFICATION of run 4's carrier curve** (replay
   analysis, started):
   Truth from bench source (godon-bench-generic sim.rs):
   - sim.rs:139 `"threshold" => if np > 0.5 { 1.0 } else { 0.0 }`,
     np = level/100 → TRUE EDGE AT LEVEL 50 (response 0 at ≤50).
   - sim.rs:258-262 receiver obj[to_ch] += strength × sender
     obj[from_ch] (iterative relaxation); weights obj0=[0,.5,0],
     strength 0.7 → TRUE PLATEAU = 0.5 × 0.7 = 0.35 above edge.

   Measured vs truth (deviation in bars):
     lvl  0: +0.24 ±0.37 | 0.00 | 0.65σ ✓
     lvl 25: +0.26 ±0.36 | 0.00 | 0.72σ ✓
     lvl 50: +0.04 ±0.13 | 0.00 | 0.31σ ✓
     lvl 62: +0.41 ±0.16 | 0.35 | 0.38σ ✓  (and 2.6σ from 0 → risen)
     lvl 75: +0.59 ±0.37 | 0.35 | 0.65σ ✓
     lvl 100:+0.58 ±0.39 | 0.35 | 0.59σ ✓

   VERDICT: CALIBRATED — truth passes through every measured bar
   (max dev 0.72σ across 6 points; textbook for honest Gaussian-ish
   errors). Edge bracketed (50,62], true edge 50⁺: bracket contains
   truth, width 12. Amplitude recovered within bars everywhere
   (point estimates trend +0.06..+0.24 HIGH — sub-bar, n=6, not
   convictable; replay across runs should track the signed-deviation
   distribution for systematic bias, e.g. pause-baseline asymmetry
   or receiver-wobble between blocks — bars vary 0.13..0.39 by level
   because the receiver is a LIVE agent optimizing between probes;
   the bar honestly reports that).

   THE HONEST LIMIT (user pressed exactly here): converged means
   SELF-CONSISTENT, not TRUE-RESOLVED. The unmeasured interval
   (50,62) could hide the edge anywhere — an edge at 58 would have
   produced an identical curve and the same claim. Convergence
   (delta 0.013) stopped the walk before it split (50,62) further;
   the walk's order WOULD have gone 56 → 53 → 51 → … toward the
   edge. Resolution is therefore a KNOB TRADEOFF
   (convergence_threshold), and the principled edge-precision rule
   is rung 3: movement-driven depth — keep splitting the largest
   response-jump gap until adjacent points' bars overlap
   (resolution criterion, not stability criterion). Run 3c level-100
   reading 0.499±0.279 also contains 0.35 — cross-run consistent.

9. **The priced stop — the design note this deserves, in plain words**
   (settled in discussion; implement after export-PR + saturation cell).

   TWO SEPARATE QUESTIONS THE CURVE ANSWERS:
   a) "Is my map stable?"  → convergence/delta (SHIPPED): repeated
      measurement keeps agreeing. Run 4 answered yes at bracket (50,62].
   b) "Is my map GOOD ENOUGH?" → priced stop (NOT shipped): compare the
      cost of remaining ignorance against the cost of one more probe.

   THE PRICED-STOP ARITHMETIC (run 4's carrier, worked):
   ```
   remaining ignorance = jump amplitude × bracket width / range
                       = 0.35 × 12/100 = 0.042
   measurement noise (local bar)          = ~0.13
   0.042 < 0.13  →  already can't see the difference  →  STOP is right
   ```
   Run 4's stop at (50,62] is therefore already steering-grade BY THE
   MATH — but it stopped there by convergence luck, not by this rule.
   The same convergence knob (0.02) on a noisier bench or smaller
   jump could stop too early (bracket still expensive) or waste
   probes past all value. The rule, not the luck, is the instrument.

   THE MISSING PIECE (small, two repos):
   - causal: expose per-curve "unresolved gaps" — standing state,
     recomputed every probe: gap (x1,x2) unresolved ⟺
     |r(x2)−r(x1)| > bar(x1)+bar(x2). A FACT like `converged`, not an
     event/trigger; eligibility consults it like it consults
     `converged`. Shape-blind: smooth curves resolve by agreement
     (difference shrinks with width), steps never do (floor stops
     them) — shape becomes an OUTPUT of termination behavior, not an
     input to code.
   - breeder: two-key retirement — eligible ⟺ converged AND no
     unresolved gaps; when converged-but-unresolved, candidacy
     restricted to inside the gaps (farthest-point then bisects
     automatically). Termination = priced stop (amplitude × width ≤
     local bar) with the grid floor as hard backstop.
   - What it costs when it fires: ~1 dead param's worth of probes to
     take (50,62] → (50,56] etc. — available on demand, but the priced
     stop says: usually don't.

   WHO NEEDS PINPOINT EDGES? Steering needs bracket+margins (command
   away from edges, never ON them). Paper 2's stronger claim is the
   certified bracket itself. Only a future job that repeatedly
   commands AT the tipping point would pay for floor-exact edges —
   doesn't exist today.

   VALIDATION OWED before building: one saturation-carrier bench cell
   (smooth-steep region) — watch a gap resolve BY AGREEMENT (no floor
   involved). That's the falsifier for the shape-blind claim. Order:
   export-PR → saturation cell → this PR.

   STATUS SUMMARY, one line: the map we have is good enough (verified
   vs ground truth); the machine doesn't yet know WHY it's good
   enough — the priced stop puts that knowledge in the instrument.





