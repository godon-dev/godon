# Session 2026-08-23: Multi-Receiver Engine + THE COMPOSITION GATE

The day the map became a machine. One engine flaw found and fixed,
three PRs merged and deployed, and in the evening: the composition
gate — identity, prediction, and steering, all green on first fire.

## The flaw (found by design review before it ever bit)

The observation SQL pulled ALL non-sender rows into one series and the
curve registry keyed (sender, param, channel) — correct only while
every run had exactly two breeders (one-minus-one leaves one listener).
With a third breeder, listeners' readings merge silently: no error,
wrong curves. Not predecessor sloppiness — an invariant true by
construction until N grew. Nobody had pinned "exactly one receiver"
in a test.

## The fix (three PRs, merged, deployed)

- images #287: curves keyed (sender, RECEIVER, param, channel);
  per-receiver SQL grouping; /characterize returns per-receiver map
  (top-level fields = primary receiver; single-receiver case identical
  to old behavior); curve_points.receiver_id (ALTER self-migrate,
  legacy rows replay as 'unknown'). README catch-up rode along.
- breeders #194: per-receiver CHAR TELL lines; all-receiver retirement
  falls out of the aggregate fields (zero logic change); dead local
  _compute_probe_shift removed (same mingling SQL, zero call sites).
- godon #314: bench workflow generalized to N breeders; two scenarios:
  scenario-verification-star (edge + disconnected witness) and
  scenario-composition-gate (chain 0.7/0.5, saturation carriers).
- Deploy: godon-causal-0.16.0 + breeder 0.155.0 tagged, chart 0.44.0,
  full restack, gates verified.

## Verification (the edge+witness run, 3 dispatches)

- Receiver separation proven on every run: two listeners, same
  windows, different readings (−0.50 vs flat in identical windows).
- Final star data: carrier tent 8 levels, every point ≤ ~0.011 from
  planted truth (~0.5σ); witness flat ±0.015; ch1 flat; reverse flat.
  Exactly the planted structure exists, nothing else.
- Workflow gate lessons (3 misses, all mine): poll gate 60 too
  shallow; 350 starved rotation; 550 > the breeders' 500-iteration
  cap → impossible gate, badge lies "cancelled", data exports anyway
  (always() step). Fix owed: poll gate should read walk state, not
  raw trial counts. Read config caps BEFORE dispatching.

## THE COMPOSITION GATE (run 32637299365, completed success)

Chain: node-1 —0.7→ node-3 —0.5→ node-2. Node-1's single walk
measured BOTH curves at 9 shared levels (two-hop free via multi-
receiver). All 36 curves: exactly the 3 planted signal paths non-flat;
sink's walk blank; reverses flat; ch1 flat.

IDENTITY (in-sample): measured curve(A→B) vs 0.5 × curve(A→C):
9/9 levels within 2σ; median deviation 0.18σ. The composed map
reproduces the directly measured two-hop response.

PREDICTION (out-of-sample, quiet bench, committed first):
  L=56: pred −0.0150, measured −0.0109 → 0.13σ HOLDS
  L=68: pred −0.0368, measured −0.0281 → 0.35σ HOLDS

STEERING PRECURSOR (first ACT in project history):
  target r*=−0.100 at node-2; map inverted itself → A=32.42
  (no human chose it); executed; landed −0.1038 ± 0.038 → 0.10σ.
  PROBE→MODEL→PREDICT→ACT→COMPARE fired for the first time.

Honest scope: quiet bench (no live agents fighting — B's optimizer
absent); additive-linear coupling physics (method proven; nonlinear
composition still owed — bench capability doesn't exist); one seed;
repeatability pair owed. Numbers: 0.13σ / 0.35σ / 0.10σ vs a 2σ bar.

## The fourth measurement artifact: first-hold transient

Receiver's first hold block moves params 0→50; its own objectives
jump (weights × 0.5) inside the sender's first push window → shift
records the receiver's initialization as structure. Seen 4× (star
runs; chain run amplified: node-3's 0→50 flows down its 0.5 edge,
+0.849 ≈ 0.5 + 0.5×0.7 arithmetic, the transient COMPOSES). Engine
handles honestly (z-spike, drift flag, priced-stop holds door, raw
point kept). In the chain run it sits UNHEALED in node-3's final
C→B curve (walk cut by rotation). cherusk's design call, parked:
seed-at-hold vs transition-tag vs leave. Vocabulary settled:
"first-hold transient" (real motion, misattributed) ≠ "phantom
shift" (structure that exists nowhere).

## Also settled today

- Sentinel vocabulary: workshop "witness" (agent) / "blank" (reading);
  papers: "negative control". "Star" scenario was really
  edge+witness — name kept in repo, noted here.
- Chain identities: A's walk feeds BOTH receivers at identical levels
  (two-hop free). Composed amplitude 0.35 > 0.1–0.2 detection floor.
- Poll-gate fix spec: read walk state (all senders DONE/converged),
  not trial counts.

## Next session

1. Evidence PR: chain curves + identity + prediction + steering
   numbers → papers/characterization (data + summary row).
2. Poll-gate workflow fix (walk-state gate).
3. cherusk's call: first-hold transient fix (seed-at-hold preferred?
   cleanest — removes the move entirely).
4. P3 skeleton can now be drafted honestly: method-level composition
   proven; nonlinear capability + live-B rung + repeatability named
   as boundaries.
5. Doc one-liners owed: grid folded into P2; diligence pre-submission.

## Artifacts

- /tmp/chain_curves.json (36 curves, final export) + CI run
  32637299365 logs (permanent). Star: 32633729366 (+earlier
  32631063923, 32630439204).
- Scripts (session-local): identity_check.py, gate_change_tests.py,
  curves extractor, star_verdict.py.
- Quiet bench container bench-gate (8095) left on runner — remove or
  reuse for repeatability.
