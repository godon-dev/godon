# Session Notes — Sep 2, 2026: composition wave 2 + lease fairness fix

Wave runs (all verdicts on godon#346), two engine fixes merged, and the
set of laws the session banked. Evidence figures in
`papers/characterization/evidence/`.

## Runs

- **cliff-v1** (33597128644): planted relay UNREACHABLE — f_sat caps at
  0.5 = strict threshold fire line, dead plant by arithmetic. Salvaged:
  first point-wise closed-form shape validation (n1→n2, 18/18, worst
  z 0.61) + no-phantom-firing receipt. Born: pre-flight authoring gate
  (far-end span ≥ several σ AND fire-line reachable).
- **cliff-v2** (#347: thr relay mid-chain, tail sat w_own=1, edge 0.45)
  (33623243676): composition through a LIVE discontinuity — 33/34 within
  2σ. The one miss: a read taken while n3's own dial was off-park —
  the label-by-total-level law materialized in data.
- **poly** (33607018911): shape validation 12/12 + 12/12 (poly piece,
  sat∘poly), spans 30σ/18σ. w_own=0 → shape row, not composition row.
- **junction seed 47** (33634967561): lease starvation struck — n4
  self-map 3 pts. 20/22, both misses localized to the coarse-map region
  (low dial). Before-receipt of the fairness fix.
- **junction seed 48** (33644675248): starvation again (3 pts), but
  14/14 nominal BY LUCK — readings sat near the coarse linearization.
  Verdict quality under an unfair scheduler is a lottery. Excluded from
  certification; second before-receipt.

## Engine fixes shipped (merged Sep 2)

- **godon-breeders#198 — lease fair-share.** `walk_pending` +
  `acquire_count` on interference_active_breeders; acquire denied while
  a walk-pending peer has fewer turns. Race-proof, no tuning coupling,
  no solo tax, newcomer priority, done peers never block. First draft
  (reacquire backoff) superseded same day: it restrains only the last
  holder — unfairness migrates. Lineage: fair queuing '89 / max-min /
  DRR '95 / CFS vruntime / nginx SWRR, at weight 1. 318 tests.
- **godon-charts#257 + #258 — loki OOM fix + breeder 0.159.0.** loki-0
  was OOMKilled-looping (13 restarts, exit 137): 512Mi limit, WAL on
  emptyDir, retention_period set but never enforced (compactor
  retention_enabled missing). Fix: 2Gi, PVC 20Gi, retention enforced
  (7d). Reinstall fired 17:32Z; doubles as ghost-curve bank reset.

## Laws banked this session

- Label curves by TOTAL LEVEL, never by knob position. Level is level;
  local movement is orthogonal at level-addressing, broken only by
  dial-addressing, memory, or latency.
- Pre-flight gate: planted far-end span ≥ several σ AND fire-line
  reachable — executable check; old cliff FAILs it, new PASSes.
- Verdict quality under an unfair scheduler is a lottery —
  certification needs fair scheduling.
- Fair-share by turn counts beats restraint (backoff migrates
  unfairness to the next-fastest poller).
- What-if = re-simulation on an edited map. LLM asks/translates, map
  computes, bars price. Every steering act runs one first.
- Drift: counter-movement is drift with an author. One new author of
  movement per rung: time → own hands → the system itself (loops).
- M6 survives as prior-with-verification, gated by the drift-economics
  receipt (map half-life ÷ refresh cost).

## Steering doctrine settled (design note pending)

Steering is an activity, not an entity — tenders hold the verbs and
switch modes. Guardrails port up a level (predictive + reactive both).
Cadence policy is the stand-in clock until the stateful tier. Live-B
demoted to steering's final exam. Blast-radius-scoped freezes, never
global. Shard roles + coordinator modes (#0) ride the same note.

## Open after wave

- Fair reruns of junction seeds 47/48 (post-reinstall, post-0.159) →
  certification rows for P3.
- P3 writing — evidence complete except fair-seed rows.
- Ledger consolidation into docs (seven areas: steering-into-engine,
  engine, data model, consumption, comprehension, benches, more) —
  awaiting go.
- Steering design note — awaiting go. Data model designed in chat,
  needs its page: target keys, level labels, epochs discovered not
  declared, raw trials as truth, five floors, snapshot = prior with
  verification recipe.
- Chart PR #258 merged; reinstall in flight at write time.
- Docs staleness: INDEX/essence still call composition "untested
  keystone"; engine-status version table stops at Aug 8. Curve-store
  ghost families pre-date the bank reset — schema (target keys) is the
  durable fix; reset is the stopgap.


## Triage-debate learnings (Sep 2, evening)

- **Memory-driven triage leaks; document-driven holds.** A triage built
  from memory one hour after reading the docs dropped ~12 items. The
  seven-area ledger exists because of that.
- **The seven-area portfolio is the better ontology:** steering-into-
  engine / engine improvement / data model / user consumption /
  comprehension / benches / more. Actions live inside areas, not the
  reverse. Funding rule: comprehension always; foundation once, now;
  payoff next; maintenance just-in-time; consumption gated; benches
  follow.
- **Consumption was never gated on steering.** Diagnostics-as-entry-
  point (strategic-analysis #4) — bounded scan → map with bars →
  isolation verdict — is buildable on existing P1/P2 receipts. The
  steering show comes later; the diagnostics show is already backstage.
- **Data model = the moat, documented since strategic-analysis #3:**
  "trial data dropped on breeder deletion is the wrong default."
  Target-bound ownership is the schema answer; breeder was only ever
  the instrument (the historian's name on the subject's file).
- **Two drift flavors, two cells:** drift_rate exists in sim.rs
  (noise inflation — YAML-only cell, tests bar honesty); structural
  drift (planted truth changes at tick N) needs a small sim scheduler
  and is the real M6 referee (map half-life ÷ refresh cost).
- **Restraint migrates unfairness; accounting is tight.** Fair-share
  by turn counts has named ancestors (fair queuing '89, max-min, DRR
  '95, CFS vruntime, nginx SWRR) — components not new; the assembly
  is the contribution.
- **The clock check before diagnosis:** the "19:14 stack recreation"
  never happened — pod ages misread against a drifted sense of time.
  Verify the clock before diagnosing an event.


## Certification status update (Sep 2, ~21:15Z)

- **cert-47 fair (33673972892, breeder 0.160.0):** completed/success.
  n4 self-map STILL thin — 4 pts. 13/5 referee. **The thin self-map
  reproduces under fair scheduling → NOT lease starvation.** All four
  walkers show walking state in the poll loop. Suspected: node-4's
  walk converges early (its incoming is constant-zero parked — relay
  silent → clean reads → fast convergence → refinement not firing);
  seed-dependent via the junction's firing state during its walk.
- **Filed as godon#348** (awry → issue per standing instruction):
  includes the cross-run pattern table and investigation pointers
  (flow logs for breeder ac80c226 in Loki).
- **fair seed 48 (33673988909): walking**, verdict ≈ 23:45Z. Its n4
  self-map richness = another data point for the #348 pattern.
- P3 junction rows lean on seed 46 until #348 is understood. All other
  P3 evidence rows complete.


## Certification close-out (Sep 2, ~23:55Z)

- **fair seed 48 (33673988909, breeder 0.160.0, fair-share):** 25/31,
  6 misses ALL at L ≤ 32 — the 3-point self-map chord's linearization
  error region. n4 self-map 3 pts (x = 0/50/100) — THIRD thin
  occurrence, scheduler-independent, relay pieces rich (31 pts).
- **#348 updated** with the third data point. Junction certification
  rows are BLOCKED on #348 (the walk-refinement question). Seed 46
  remains the junction reference row.
- **Wave closed.** All other P3 evidence rows complete. P3 writing
  begins; the plan lives in session-2026-09-02-p3-plan-and-handover.md.
- Morning reading for cherusk: #348 (the open question) → #346 (wave
  ledger) → the P3 plan.


## #348 SOLVED (Sep 2, ~23:58Z)

Loki flow logs (fair seed 48): node-4's self-walk detected **4 priced
gaps and bisected them to 1** (21:58 → 23:09) — the refinement and the
fair-share scheduler both working exactly as designed. The run's timing
ended before the last gap closed. The 3-point map = honest state at the
clock, not a bug.

- Failure class: budget, not mechanism.
- The fairness fix VERIFIED live: under the old scheduler node-4 never
  got turns (no bisection at all); under fair-share it bisected 4→1.
- Fix: junction-gate timing end extension (one YAML value) + fair-seed
  rerun → certification completes. Awaiting cherusk's morning go.
