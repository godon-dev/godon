# Session 2026-08-27 — P2: swept, written, published

## Thread 1 — the 32-cell characterization sweep (COMPLETE)

Started from grid planning (this session's opening), finished 32/32
banked in ~1.5 days of mostly-unattended bench time.

- Runner: /tmp/sweep_runner_p2.py (grid embedded, dispatch→wait→
  fetch→score→bank, failure brain, adopt-mode for in-flight runs).
  NOT committed anywhere durable — copy from /tmp if needed again.
- Harness fixes en route: workflow #316 (walk-state gate, merged
  pre-session), #317 (dispatch overrides + N-generic rewrites + 4
  scenario dirs), #318 (target-name sed + stale-uuid cleanup),
  #320 (Loki non-fatal). Runner-side: real-marker regex, raw
  jobs-API transport (gh --log returns empty), channel-string
  scoring, data-over-badge verdicts, token auto-re-mint on 401
  (the overnight bank-skip bug), adopt mode.
- Results: 24 within-bars (max 1.76σ, median 1.03σ), 4
  structure-banked, 3 bridge-parked, 1 flat-sentinels-clean.
  Recomputation pass over all scalar rows: CSV confirmed exact.
  Full per-cell table with run IDs: issue #323.
- Headlines: floor 0.1 (3 honest levels); noise wall σ0.10 at
  0.5/0.7/0.9 incl. r3 = same-cell vs P1's detection failure
  (0.62σ); threshold 15-level self-allocation, cliff bracketed
  50→56 unsampled; ns3 bars fatten honestly under growing noise
  (certified but coarse — sized so in the paper); ns5 fast drift →
  honest non-convergence, 22-level probe.

## Thread 1 findings — engine (filed in engine-status.md)

1. Lease fairness at N≥3: one sender dominates, others starve.
   Fix owed (round-robin or per-sender budget) before multi-walker
   P3 claims. N=2 fair (e2 both directions clean).
2. First-hold transient, three receipts (e3/e6/diamond): receiver
   init (params 0→50) recorded as structure on in-flight sender
   curves. Seed-at-hold fix promoted to P3-prerequisite.
3. Walker classification (notes): ignorance-priced adaptive survey;
   dual-use sampler observation; BoTorch = component/consumer not
   competitor. Bench capability gap table (per-edge f_edge, variance
   coupling, structural drift, stateful-tick keystore) with sizes.

## Thread 2 — Paper 2 WRITTEN + PUBLISHED (same session)

- **DOI: 10.5281/zenodo.22127166** — From Edges to Curves:
  Calibration of Autonomous Coupling Characterization in Live
  Systems. Record verified (title, ORCID).
- Draft built end-to-end: figures from banked curves via
  make_figures.py (shipped in papers/characterization/paper/),
  tectonic builds (amssymb/amsthm/parparsy pitfalls; P1 preamble
  is the reference).
- PRs: #322 (evidence: 32 cell dirs + sweep.csv + summary),
  #324 (draft), #325 (P1 PDF ORCID rebuild — committed artifact
  was a stale pre-fill build embedding 0000-0000-0000-0000),
  #326-#329 (keywords/categories iterations).
- Editorial decisions (his): title keeps "in Live Systems" (domain
  word; "Non-Stationary" narrowed); no z.ai in header, in body of
  posts; agents not optimizers; walk not "instrument"; keywords
  carry subject (coupling characterization) not verb (calibration —
  title's job, metrological sense stated in §3); no printed arXiv
  categories (P1 pattern), saved for endorsement day: cs.MA +
  eess.SY/stat.AP/math.OC; harder sections expanded with more
  words (priced-stop intuition + worked examples, two-dials
  dwelling/levels, three defects with visible signatures).
- Honest-size fixes caught in review: trials-cost sentence was
  unbacked (replaced by measured wall-time/levels facts);
  banked-maps-byproduct claim moved to future work; ns3 bars
  sized as coarse; "not detected" not "failed" for P1's detector.

## Thread 3 — outreach + records

- LinkedIn: org description (mission version chosen — "Complex
  systems shouldn't be endured — they should be tended"); P2 post
  (main + short variants, P1 structure); his personal repost
  (two-beat, deduped). Discord share (condensed, his P1 format).
  Post texts saved: docs/linkedin-post-p2.md.
- godon-documentation: P2 added to publications page (PR #108,
  merged — site deploys from main).

## OPEN ITEMS (next session's queue)

> LATER SESSION (Aug 27, evening) — composition bench phase 1
> STARTED. Long design convergence with cherusk, all of it his:
> edges = magnitude only (logical, forever); nodes carry ALL
> maps. The insight chain: P2 measured nonlinear CURVES through
> linear edges (shape lived on the sender's own base —
> composition was arithmetic by construction, hence the Aug 23
> gate's linear result; nothing banked is false, the boundary
> was printed). The permission to chain = property of the
> substrate, never tested. Fix: intake-through door — incoming
> coupling joins the receiver's CHANNEL STATE (own weighted
> input + incoming), base map acts on the combined level once.
> "Level is level" physics; junctions (mix-then-map vs
> map-then-mix) deferred to phase-2 diamond; edge-knob dropped
> (a nonlinear pipe = intermediate node with parked params).
> SHIPPED: PR #288 godon-images feat/intake-door @ 166b1e7 —
> intake field (default post = legacy), door rewire, 3 new
> tests + 3 legacy regressions, all green (local cargo 1.98;
> rustup+gcc+libc6-dev+libssl-dev installed on box). NEXT: his
> review/merge #288 -> first door-only 3-node scenario in
> godon repo (needs his file-creation go) -> N=2/3 walk cells.

> 2026-08-27 later session update: item 2 advanced (committed, push
> pending his PAT), item 3's dirty-cache half solved structurally.
> Render follow-up SHIPPED: source PR #108 alone never went live —
> Pages serves the committed `/docs` build, so a render PR was
> required: PR #109 (rebase-merged 2451f5c, deployed 13:39Z, live
> verified: P2 on publications, robots.txt 200). Social cache
> untracked in the same PR — builds stop leaving dirty noise.
> mkdocs 1.6.1 + material in /tmp/venv; build from material/ with
> `-d ../docs`; cache dir needed chown (was uid-1000).

1. Zenodo record: evidence bundle DEFERRED by cherusk's call
   (Aug 27) — it's checkability insurance, not urgency; clean up
   later (at P3 submission or first external ask). Scope if
   revived: cell curves + sweep.csv + gate curves + summary +
   main.tex/make_figures.py (rebuild-me chain), MANIFEST with
   run IDs (#323), via record's New Version.
2. cherusk profile README: P2 entry committed 4b865e2 on
   profile/readme-final (on top of unpushed 48d0d6c). Push = his
   PAT (app token godon-dev-scoped). He pushes himself.
3. godon-documentation leftovers: stray local branch
   `profile/p2-publication`, one stash entry (moot), and origin's
   merged head branch `chore/site-render-p2` — sweep on his go.
   Dirty cache file problem: GONE (untracked via #109).
4. P3 build list (in order): nonlinear-composition bench (per-edge
   transfer functions — the gate), lease fairness, seed-at-hold,
   adaptive dwelling / cost instrumentation (trials-per-level
   not recorded this campaign).
5. Diligence residual: journal-only literature (power-grid state
   estimation, adaptive causal discovery outside arXiv) — arXiv
   slice swept, note in paper-status.
6. arXiv: both papers pending endorsement; P2 categories decided.
7. Docs notes stale lines (lower priority): essence/INDEX still
   call composition "untested keystone"; engine-status version
   table stale at Aug 8.

## Operational lessons (this session's scars)

- After ANY branch-PR flow: pull main before claiming anything is
  "on disk" — twice bitten (#325, #326) by checkout reverting the
  working tree. Hard rule now.
- Data-over-badge includes MY narration: verify from API/CSV
  before stating run states (the "562 minutes" and "7h walking"
  embarrassments were both cached-subtraction lies).
- gh run view --log returns empty on this runner — jobs-API
  transport is the reliable path (baked into the runner).
- Wedged GH run (#60): created+started, zero jobs, uncancelable,
  undeletable without admin — only cure is fresh dispatch; the
  zombie rides the Actions list forever.
- Root-owned dirs (/projects/cherusk): stage via /tmp + sudo cp;
  git must run under sudo there.

---

# Addendum 2026-08-28 — dense verdict + the experimenter architecture

## Run 33172249837 (dense, seed 42) — composition certified on anchor cell

20/20 ×3 COMPLETE trials. F n=9 σ̂.1568, D n=9 .1927, G n=6 .0344.
Verdict (door_verdict4.py; B hold-baseline 0.3363; trials from
trials_v8_char3.json — NOTE: harvest3.sh banks trials ON THE BOX,
scp needed; char2 purged to 0B at cleanup):

- 6/9 levels certified (L=38..100), 6/6 within 2σ, max z 1.24,
  median .57. Refused L=0/13/25 — B-door slices .493/.410/.387
  never sampled. Running total both runs: 14/14 covered points
  within 2σ.
- Precision (door_precision.py): pred 1σ median .0186 vs direct
  .0162 → composition cost 1.33× median, 2.50× worst. Bars are
  noise-floor bound (σ=.02 planted, walk span .066, SNR ~3:1 by
  construction). CAVEAT (mine, named): interpolated slopes treated
  as EXACT — slope error from sparse points not propagated; the
  1.33× may be understated.

## Park/overlap receipt (his catch)

- Receivers DO hold neutral (B@50, 12:45–13:05, 299 holds).
- Finished sender does NOT return: A's final standing param 100,
  no reset after 13:15:48.
- WORSE than the one-line story: walks overlapped — B walked
  12:55–13:20 while A wandered 0→50→80→100. G banked under
  blended regimes and STILL 6/6 truth (robustness bonus).
- Protocol lines owed: park-at-neutral + one-walker-at-a-time
  (serialization). Fix is two lines, not one.

## Design conversation (ALL PAPER, ZERO CODE; ontology untouched —
zero rulings revisited, the base held through every new question)

- Lazy measurement: request → compose → refusal names the missing
  slice (pair, range, neighbor state) → targeted walk. Bank =
  cache; refusal = priced shopping list. "Pairs are the capital,
  refusals are the purchase orders."
- Two-tier: crude screen upfront (edges carry magnitude — THAT is
  why the screen is affordable; it also defines the graph, the
  composition domain via measurably-transitive, and seeds the bank
  warm) + lazy precise maps. drift_rate knob already in
  topology.yaml = the planned drift cell.
- Scheduler: ONE priority queue of work orders. Priority sources:
  requests (preempt) / connectome leverage / staleness aging.
  Connectome = map AND scheduler info AND concurrency bound
  (graph coloring — the B-blend receipt is why).
- "Probe when we can" has exactly three costs: perturbation
  (act = observe, no read-only mode exists), contamination
  (coloring rule), staleness (perishable inventory). Bench
  eagerness = special case where all three ≈ 0.
- Where-to-probe: request-driven half is COMPUTABLE — bar
  attribution names the dominant term (receipt: 4/6 levels G's
  own bar ate the budget; sharpening F would have bought
  nothing). Background half = leverage × demand; decline to
  forecast by cleverness, let requests reveal demand.
- Drift = timescale comparison: drift << walk → bank with
  half-life; ~ walk → bank variance not mean ("alive at this
  timescale"); >> anything → refusal = finding. Drifting edges:
  extreme lazy, never pre-warm. Sentinel revisits on anchors =
  cheap staleness sensing.
- Steering ladder: predict / steer-open / steer-closed / track /
  refuse. Closed needs only local gradients — walkers already ARE
  that machine. Steer IS probe (same act). Freshness never
  reaches the customer — internal rung selector.
- CONTRACT open (5 questions, parked): who is the counterparty?
  minimal request? guarantee object? what may we NEVER refuse
  (safety default underneath refusals)? who pays for walks /
  owns what they learn?
- Dual control (Feldbaum) is the classical name for
  probe-with-steer; SLAM the modern cousin. "The steer spends
  the map it steers by." Dither = the one genuinely new quantity
  (certainty vs progress).
- Step-and-settle (HIS): pulse → settle → verify (banks a fresh
  point free) → next pulse. Rule: steer slower than you learn.
  Step size ∝ bar. Few invocations — each one spends map
  validity. = the bench's certified quasi-static regime promoted
  to a scheduling principle. First steering cell should run in
  this mode.
- Fraction argument (his sense, endorsed): built world is
  selected for near-decomposability (Simon); gain scheduling =
  industrial existence proof of pairwise+regime; lazy escapes
  the dimensionality curse (buys corridors, not rooms). The
  fraction is never claimed — measured per substrate by the
  cheap screen; refusals delimit it.

## Seven underside items (NOT on any list yet)

1. Slope uncertainty in propagated bars (mine — see caveat above).
2. k-parameter nodes: surfaces, region-addressing (lazy softens).
3. State/hysteresis: no cell deliberately walks a door backwards;
   the reverse cell would accidentally test it.
4. Regime-tagged curve schema — serialization implies it; undesigned.
5. Walk preemption semantics (request arrives mid-walk).
6. Inversion machinery for steering (non-monotone branches,
   achievable sets) — unbuilt, undesigned.
7. Connectome liveness: edges born/dying under drift — change
   detection on gaps, screen re-runs.

Deepest BOOKED risk: the diamond cell is the trial for the whole
lazy economics — pairwise vs joint maps. If junctions need joint
maps, the probe address space explodes N² → configurations.

## Queue UNCHANGED, on his go

Park-at-neutral line, serialization line, seeds 43/44 (anchor
repeatability), scenario linter, verdict on scale-relative
convergence criterion. Verdict artifacts: /tmp/door_verdict4.py,
/tmp/door_precision.py, /tmp/door_run_dense.log,
/tmp/trials_v8_char{1,3}.json. Issue #336 closure comment and
anchor-row banking into evidence dir still await his ok.

---

# Closer 2026-08-29 — anchor repeatability gate CLOSED (28/28)

## PR #339 (merged 2ad49d2): trials now embed in the job log

The Trials step's jq reduced full records to counts AND fetched
without a limit param — the endpoint default silently capped at
100 ("total: 100" was the cap, not the count). Now: `?limit=1000`,
jq keeps counts AND embeds records under `.trials`. Logs grew
215KB → 1.6MB. Every run log is now self-sufficient for verdicts.

## Three-world repeatability table (anchor cell, door-chain)

```
seed 42:  6/9  | 6/6  in 2σ | max z 1.24 | med 0.57 | base 0.3363
seed 43:  7/9  | 7/7  in 2σ | max z 1.49 | med 0.28 | base 0.3381
seed 44: 15/20 | 15/15 in 2σ| max z 0.64 | med 0.38 | base 0.3402
          28/28 within bars, zero misses, three noise draws.
          baselines ±0.004 apart; planted 0.3393.
```

Runs: 43 rerun 33238378217, 44 rerun 33240317830 (both success,
verdicts from logs alone). Refusals: low-L hole in ALL worlds
(parking artifact, fix queued); L=50 in 44 = anomalous F point
(delta −0.35, 10× neighbors) REFUSED by the join, not composed
through — first live receipt of refusal-as-data-quality-guard.

## Planted-anchor calibration FAILED (receipt, important)

Tried verdict with planted join (sim.rs mirror: baseline +
S(P)=sat(P/100+0.9)) on run 42: got 4/9 with a 3.16σ outlier vs
truth 6/9/1.24. Cause: G was banked under BLENDED A-regimes (A
wandering 0→50→80→100 during B's walk) — single-regime planted
join cannot reproduce the measured join. Mirror itself verified
(planted 0.3393 vs measured 0.3363, 0.15σ). Consequence: the
self-map (knob → own absolute output, regime-tagged) must be
MEASURED → SELF-CURVE promoted to P3 build item (nodes carry
maps; the self-map is currently homeless in trial metadata).
Underside item #4 proven necessary by failed verdict.

## Scars (all named, all mine where applicable)

1. Trials live only between run start and cleanup. 43's trials
   (428/439/379KB banked 20:57) overwritten by MY 21:18 harvest
   (current-list uuids = 44's breeders, untagged filenames).
   44's trials zeroed by its watcher's completion-frame refetch
   AFTER cleanup. Discipline: pinned uuids, run-tagged files,
   never shrink-overwrite; better: read trials from the log (#339).
2. Same seed ≠ same walk. Shared noise stream, interleaving-
   dependent consumption → different trial sequences, different
   level sets. NEVER claim seed-reproducibility; reruns are
   independent draws (good for repeatability, kills determinism).
3. Job-log blob 404s right after completion — wait ~60s.
4. Logs endpoint feels token rotation first — re-mint on 401
   (runner doctrine), get_token needs /tmp/venv/bin/python.
5. Background process output buffers until exit — "silent watcher"
   ≠ dead watcher; check by hand before killing.

Artifacts: /tmp/verdict_from_log.py (log-only verdict, post-#339),
/tmp/fetch_runlog.py, /tmp/door_run_s43b.log, /tmp/door_run_s44b.log,
/tmp/door_verdict_planted.py (the failed calibration, kept as receipt).

## Standing queue (his go, unchanged)

Park-at-neutral + serialization (protocol lines — close the low-L
hole for every future cell), scenario linter, scale-relative
convergence verdict. Anchor repeatability DONE → campaign fans
out after the protocol lines.

## Design thread Aug 29 (post-gate): the substrate agent

STATUS: CONSIDERATION ONLY — design talk, NOT decided, NOT
queued for build. His explicit flag: do not treat as ruling.
Open question he raised: does this reinvent kubernetes?
(Working answer: no — the agent is a LEAF deployed by existing
orchestration, not a control plane; it shares one pattern
sentence with kubelet, not a codebase. Guard: the agent never
learns about peers, never schedules, never coordinates —
single-node, five-line contract. The moment it grows a second
node's worth of knowledge, it is a bad k8s clone and dies.)
Follow-up consideration: hook into k8s directly? Split: engine
already runs on k8s (bench stack); for TARGETS k8s is one
deployment vehicle (DaemonSet; optional Operator/CRD as
packaging for the k8s ecosystem) — but cannot be the hands
(knob whitelist too small, wrong latency class, no trial
ledger) and must not become the required spine (most
wilderness is not k8s). Five-line contract stays universal;
spine stays Windmill.

HIS DEFINITION: "clever convenient hands — nothing more."
Agent = hands, clock, ledger, fence. Engine keeps ALL judgment.

- Pattern: kubelet (engine = control plane, agent = node
  daemon). LEVEL-TRIGGERED desired state, never command
  queues — reconvergence absorbs reboots/crashes/rate
  mismatch. Bench container = proto-agent (sim.rs /apply +
  /metrics IS the skeleton); all certified engine behavior
  transfers unchanged to agented targets.
- Provides: intervention-locked reads (apply+read one clock,
  one trial id — the attribution curves rest on; Prom's async
  scrape structurally lacks it); dead-man decay to safe
  params (park-at-neutral enforced AT substrate, heartbeat
  loss → revert); whitelist fence (knob vocabulary+ranges =
  least privilege as grammar); ownership claim (walk-overlap
  structurally impossible at target); WAL persistence; trial
  ledger (ids → dedup, crash-resume); recon ring buffer
  (sentinel stream survives engine absence).
- Protocol: blocks and drains — submit-block / drain-since-id
  / claim+heartbeat. Three calls, no streaming framework.
  Batches for WALKS only; steering stays single-act.
- Decoupling preserved: engine = godon knowledge only; agent
  = substrate knowledge only; contract = only shared surface.
  Safety decisions at agent (watchdog, locks); scientific
  decisions NEVER. TRIPWIRE: the day the agent retires a
  curve, the philosophy is broken.
- Coexists with Prometheus (ambient monitoring stays;
  agent owns intervention-locked reads only).
- Effort honesty: core = weeks; trust = years (crash
  consistency, auth surface, platform matrix = the tail).
  Phases, each convicted by the previous one's receipts:
    1. dumb shim (hours, no tail) — SSH/sysctl, covers first
       crude screen (SSH latency irrelevant at screen cadence)
    2. shim + systemd: WatchdogSec + ExecStopPost reset =
       decay-to-safe nearly free
    3. agent only at MEASURED walls: walk cadence capped by
       SSH round-trips, attribution gaps, contention.
  Generic core + small substrate drivers (new target = a
  driver, never an engine change). Rust: static, unattended,
  same toolchain as the bench sim.
- Timing: design banked; build at substrate #1's go.

## HIS RULING (Aug 29): bench-first phase

Linux box (substrate #1) DEFERRED — improve the engine with
benches as far as possible first; box only on his go. Every
campaign cell now doubles as engine development: self-curve,
regime tags, work-order loop, preemption, k-param, reverse/
hysteresis, drift cells — all bench-verifiable with planted
truth as referee. Forge cells (fairness, scale-once, parallel)
rise in priority alongside the science cells.

LATER SAME DAY — campaign structure settled into two rings,
both fully in vitro (his point: engine hardening needs NO
real substrate at all):
  SCIENCE cells: substrate physics (cliff, reverse,
    compressor, noise wall, depth, diamond, drift...) —
    verdict = z-scores.
  FORGE cells: engine hardening (settle-time, shared-state,
    apply-failure, RESTART, UNREACHABLE, fairness, scale,
    parallel walkers, timing-constants→config) — verdict =
    recovery checklist (failed loudly? bank intact? no
    blending across fault? re-anchored? resumed clean?).
    Two injection levels: harness-first (kill pod/drop
    tunnel via workflow timer — free, zero sim code),
    sim-level later (failure_rate, restart_at_trial knobs).
    Receipts already exist: tunnel-resurrect PR #335 = the
    first unreachable cell, run unplanned.
  Consequence: the box's irreplaceable value = ambient
  reality + stakes ONLY. Everything else rehearsed in vitro.
  Box is reached only when nothing is left to learn without
  it.

## Chat-only insights rescued into notes (end of Aug 29 night)

1. STRAINS DISCOVERY: godon-breeders/strains/ IS the
   substrate-knowledge layer — pluggable, strain_loader,
   suggest_params per substrate. linux_performance/
   (2019 vintage) carries a 1,627-line PARAMETER_REGISTRY:
   typed knobs, typical_range, categories (sysctl/sysfs/
   cpufreq/ethtool), causes_downtime flags (= the quiesce
   metadata, pre-written). The agent briefing's engine-side
   half ALREADY EXISTS. History: godon was BORN a remote
   Linux performance tuner (remote brain, SSH hands, no
   on-box component — his correction); bench was scaffolding
   for the science. Registry kept the WHAT; campaign earned
   the HOW; box phase spends both.

2. NODE = BENCH ARTIFACT: nodes exist for seeding/plating
   the sim. Engine's atoms are params + measured couplings.
   On Linux, node-ness is a FINDING — the partition of the
   param-coupling graph (namespaces are a prior, not a
   boundary; same-namespace params may be separate nodes).
   The screen's deepest job: return the partition.

3. ABSORPTION LADDER (ontology extends itself): refusal =
   anomaly detector → phenomenon PROMOTED to typed
   measurement (drift→half-life, blending→regime tags,
   oscillation→envelope+period) → INTEGRATED (phase-gated
   walks, route-around, damp-then-map, envelope composition
   via interval propagation — bars ARE intervals, math
   mostly paid for). Frontier retreats rung by rung, by
   receipt. "Its failures are its primary export."

4. BENCH IDEALIZATIONS (de-idealization audit): apply =
   instant/always-succeeds/atomic/no-side-channels/
   memoryless; recon = instant/exact/no-observer-effect/
   ambient-zero. Most plantable in vitro (settle-time,
   shared-state, apply-failure cells queued); residue =
   ambient unpredictability + stakes = the box's trial.

5. P3 RELATED-WORK GOLD (from RL/autotuning discussion):
   understanding = five testable abilities: counterfactual
   (inference), transfer (composition), attribution,
   audit (receipts), refusal. Autotuners have none — they
   find settings, discard their GP posteriors. "godon is
   what happens when you keep what the optimizers throw
   away." Model-based RL = closest cousin; godon =
   model-based learning with metrological discipline
   (bars, refusal, composition). Never claim general
   superiority — domain truth: when trials cost and the
   substrate matters.

6. AGENT THREAD FINAL STATE (consideration): install is
   unavoidable for safe effectuation → agent = sleeping
   hand (socket-activated, no daemon), SSH = road only;
   requests self-describing (knob, engine, value, range);
   constitution = hard per-engine limits + road protection;
   v0 ~1.5-2k lines incl. ethtool/tc families (substrate #1
   needs them); single-knob v0 (atomic trivially), v2
   semantics (transactions, idempotent replay, claims)
   receipt-gated. Script stage unnecessary once install is
   owed anyway.

---

# Session 2026-09-01 — park-at-neutral shipped (both protocol lines)

## Re-entry state (verified, not assumed)

- Board clean: zero open PRs/issues (incl. #336 CLOSED), zero runs in
  flight. Last runs = seed 43/44 anchor reruns (3d old).
- Linter SKIPPED by his call ("we often still change the config etc").
- Scale-relative convergence criterion: still parked with him.

## Conviction data (dense run 33172249837, from trials_v8_char{1,3}.json,
effectuation_params timeline — the receipts behind both protocol lines)

- A's walk ends CLEAN at neutral 50 (last pause block 12:55:12).
- 12:55:15 — DONE/COOLDOWN return optimize/None → worker applies TPE's
  suggestion: 100.0 five seconds after finishing. A stands at 100 for
  C's ENTIRE walk (13:05–13:15: 159 cooldown-100s + 36 optimize-100s,
  stray 80/0). C's curve banked under A@100 = the blended regime,
  now exact.
- Handoff gaps inject exactly one optimizer application each
  (100 @ 12:55:15 pre-B; 100 @ 13:02:14 pre-C).
- THIRD defect found while convicting: converged walker re-acquires
  the lease in a loop (OPTIMIZE → acquire → ask None → DONE → release
  → COOLDOWN → repeat) — A's optimize↔cooldown flip-flop 13:05+.
  Starves remaining walkers at end-game.
- Receiver holds are CORRECT (179 hold@50 during B's walk) — the
  contamination was sender-side only.

## Shipped

1. godon-breeders PR #196 (feat/park-at-neutral @ 0e354cc, CI green):
   config-gated `park_at_neutral` under interference_detection,
   default false = legacy bit-identical. When on: DONE parks,
   COOLDOWN gaps park, idle OPTIMIZE parks (solo/waiting/walk-done),
   HOLD exits park through handoff gaps, finished walk NEVER
   re-acquires (can_probe gate — kills the ping-pong). Park results
   carry no lease_phase → stay out of receiver_observations (pause-
   park shape). 9 new unit tests; 41/41 file, 312/312 suite.
2. godon PR #340 (bench/park-at-neutral): door-chain breeders declare
   `park_at_neutral: true`. Safe to merge before the image bump
   (unknown key ignored by current images).

## Ops notes

- godon repo origin URL had a STALE embedded app token (why pushes
  401'd while breeders pushed fine) — remote reset to clean URL,
  credential helpers (gh auth) serve fresh tokens now.
- Token re-mint trap: get_token.py writes /tmp/gh_token.txt itself;
  redirecting its stdout OVERWRITES the token's first bytes
  ("Token saved" at fd offset 0). Never `> /tmp/gh_token.txt` it.
- /tmp/ghenv.sh = `export GH_TOKEN=<token>` file, source it in the
  SAME command as gh/git (helpers read env at call time).

## Awaiting his go

- Merge #196 + #340 (rebase-merge).
- Version bump: breeders 0.157.0 tag → image → chart 0.44.2 → restack.
- Validation run: anchor cell, fresh seed, park flag live — success
  criterion: low-L hole CLOSED (L=0/13/25 now covered or refused for
  measured reasons), no blended-regime applications outside push
  blocks (grep effectuation_params ≠ 50 outside probe_push in the
  banked trials), C's curve banked under A@50.
- After that the campaign fans out: cliff, reverse, compressor×3,
  noise wall, depth 3/4, diamond, star, mixed, bypass, feedback,
  drift + forge cells (settle-time, shared-state, apply-failure,
  restart, unreachable, fairness, scale, parallel).

## Correction same day — the knob died in his review

He pushed twice ("why do we need this setting", then "why can we not
as default always return to neutral i meant you TWIT"). Both grounds
for the flag dissolved on honest re-examination:
1. The tender argument: OPTIMIZE-between-probes is sampler
   exploration, NOT tending — nothing wants it. Hold-at-best-known
   (a park, different point) is what a tender would want; live-B
   resistance is already a separate future mode in the notes.
2. Bit-identity: parking touches no join math — banked curves were
   all measured inside push/pause (pauses already neutral, receivers
   already held). Only the between-walk ambient changes = the
   convicted contamination. The intake-door precedent didn't apply.
Verified in code: NO lifecycle exists — one fixed interleave
(OPTIMIZE ↔ probe ↔ HOLD) from creation to run-end; no STEER state;
strategy notes open question #0 (when to characterize vs operate)
still open. So the off-state protected nothing that exists.
REWORK SHIPPED: #196 second commit 96438eb — park unconditional,
participation derived from interference_detection section presence
(the structural opt-in). Pure optimizer (no section) = pass-through,
unchanged. Ping-pong gate unconditional. #340 CLOSED (nothing to
declare). CI green. Tests: DONE parks, pure-optimizer pass-through,
ping-pong dead, cooldown/idle/hold-exit parks, no-neutral fallback.
Awaiting his go: merge #196 → breeders 0.157.0 → image → chart →
restack → validation run (anchor cell, fresh seed; pass = low-L hole
closed, zero non-50 applications outside push blocks, C banked
under A@50).
