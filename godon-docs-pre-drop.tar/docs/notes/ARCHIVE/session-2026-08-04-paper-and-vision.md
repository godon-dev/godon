> **ARCHIVED — superseded.** Kept for history only; do not treat as current.
> Current owner: `paper-status.md + essence.md`. See `../INDEX.md` for the reading map.
> Historical session log. Paper 1 completion, composition open question, honest vision assessment — captured in paper-status.md and essence.md.

---

# Session 2026-08-04 — Paper Draft + Vision Insights

## Achievement

Paper 1 draft complete: "The Impulse Protocol: Non-Destructive Coupling Discovery in Autonomous Agents"
- 12 pages, Linux Libertine, titlesec, parskip
- Two figures (state machine, sensitivity curve)
- 21 cells of sweep data in results tables
- Submitted to HAL (awaiting DOI + moderation)
- arXiv pending endorsement (cs.MA primary, cross-list eess.SP, cs.SY, math.OC)
- ORCID registered: 0009-0005-7399-5584

## Paper Positioning — Pearl Alignment (resolved)

The method runs PARALLEL to Pearl's causal ladder, not directly on it.
- Pearl's experimenter is centralized and human. Ours is distributed and autonomous.
- Pearl discovers Boolean causal arrows. We discover weighted, continuous, reversible step-changes.
- Pearl requires an external agent who intervenes. Our agents ARE both perturbers and sensors.
- Pearl's framework = special case where experimenter is centralized + model hypothesized.
- System identification = special case where structure is known + only parameters estimated.
- Our case = experimenter is distributed, autonomous, structure discovered empirically without specification.

This is "empirical coupling discovery" — a category nobody occupies.

## Non-Destructive Perturbation (new framing)

Key differentiator from chaos engineering / fault injection:
- Perturbations operate on SAME parameters agents already control, within SAME defined bounds
- Guardrails actively enforced per-trial: objective checks, system state checks
- IMPULSE_CALIB backs off exponentially on any guardrail violation (1.0 → 0.5 → 0.25 → 0.125)
- Only guardrail-passing amplitudes locked for push block
- System continues operating throughout — detection is non-destructive
- "Guardrail-bounded" is honest; "non-destructive" is the design intent

## Substrate Terminology

"Substrate" is the right word — domain-agnostic. Abstract says "physical, computational, or mathematical." The method works on greenhouse (physical), bench-generic (mathematical), and could work on code systems (computational). Don't narrow to "physical substrate."

## Paper 2 — Characterization/Calibration (next priority)

### What Paper 2 asks
"Measured a step of 0.1437. What does that number mean? How accurate is it? What does it tell me about the actual coupling?"

### Data already collected (21 cells)
- Step amplitude accuracy: within 5% across linear range (Group A)
- Noise floor: MAD tracks planted sigma closely
- Shape-dependent behavior: saturation inverts, threshold jumps, polynomial compresses
- Reversibility: falling_edge present for all detections (ABA holds)
- Sensitivity coefficient = rising_edge / impulse_scale — does this recover planted strength?
- Recovery_fraction = |falling/rising| — when is coupling reversible vs hysteretic?

### What Paper 2 needs (new engine work)
1. **Per-parameter resolution** — currently push top-3 params simultaneously, measure blended response. Need single-param perturbation to decompose per-channel contributions.
2. **IMPULSE_CALIB single-param mode** — push param_0 alone, then param_1, then param_2. Cycle through across detection rounds.
3. **Per-channel detector output** — report rising_edge per (sender_param, receiver_objective) pair, not just per objective.
4. **Param→channel mapping** — bench topology has from_channel/to_channel but sender doesn't know which param maps to which channel.

### Design of Experiments (DoE) — the efficient path
One-at-a-time perturbation is brute force. DoE (Fisher, Box, Montgomery) solves this:
- Fractional factorial or Latin square perturbation schedules
- For 3 params: 4 combinations instead of 8 (fractional factorial)
- Same information, fewer rounds
- The impulse protocol IS a DoE problem — just doing it the most basic way currently

### Threshold calibration
- CFAR threshold uses per-sample MAD but compares block medians
- Pfa=0.05 is not literal — actual false alarm rate is lower (conservative)
- Confirmed empirically: zero false positives across all noise levels
- Median-aware threshold would improve sensitivity but requires re-deriving false alarm statistics
- At noise=0.10/coupling=0.5: asymptotic threshold (k→3.0) is 0.30, permanently above signal 0.25
- Block=30 narrowed gap from 63% to 14% but can't cross — SNR limit, not budget limit

### Two fields most vital for progress
1. **Design of Experiments** — efficient perturbation schedules
2. **Statistical calibration theory** — proper threshold calibration for block medians

## Paper 3 — Composition Prediction (make-or-break)

- Chain4 proved edges measured correctly. NOT proven: do edges compose?
- If edges compose linearly: prediction engine is graph composition. Clean, fast, interpretable.
- If NOT linearly: need learned composition function. Less interpretable but still grounded.
- Diamond topology needed: tests transitive coupling false positives (A→D through B,C).
- The scanner can't distinguish direct from transitive edges — acknowledged limitation.

## Engine Flaws Blocking Experimentation

### 1. Coordination table lifecycle (MUST FIX)
- Single global table (sender_lease, interference_active_breeders, detection_readiness) survives breeder purge
- Second run after previous gets stuck — stale leases block all senders
- Workaround: full reinstall per cell (expensive, 2 min + 20 min per cell)
- Fix: tag-based detection groups. Scope coord tables per group tag.
  When breeders purged, clean only that group's coord state.
- Multiple groups coexist without interference.

### 2. Windmill script caching (MUST FIX)
- After reinstall, first bench run works (trials tagged with impulse_phase)
- Second run often loses tags — Windmill serves stale scripts despite re-seeding
- Root cause unclear: possibly script hash not invalidated on re-seed
- Detector finds 200+ trials but 0 push-tagged trials

### 3. Scaling (research question, not engineering)
- 2-4 agents proven. 50+ agents is different coordination problem.
- Turn-taking is serialization bottleneck by design (one sender at a time)
- Full pairwise at 50 nodes = 2450 ordered pairs × multiple rounds = days
- System drifts while scanning — scan rate vs. drift rate problem
- For 50+: need parallel probing groups, spatial locality, adaptive scanning, hierarchical coordination
- None of that exists — it's a research question, not engineering

### 4. Scan rate vs. drift rate (fundamental observability limit)
- How fast can you discover structure in a system changing underneath you?
- 2-4 agents on stable bench: scan rate >> drift rate. Easy.
- 50+ on live data center: drift rate might exceed scan rate.
- Connectome never converges — always a photograph of yesterday's system.
- "The method supports coupling discovery up to drift rate D" is characterization, not failure.
- Every instrument has bandwidth limit. This defines where it works.
- Needs configurable-drift bench to even test the question. Doesn't exist yet.

## Vision Assessment (honest)

### What's proven
- Detection works. 21 cells. 5% accuracy. Zero false positives. Shape-agnostic at adequate coupling.
- Protocol is real, non-destructive, deployable on live systems.

### What's NOT proven
- Composition: do chained edges predict distant-node response? Untested. Make-or-break.
- Drift detection: can prediction error localize structural change? Plausible, untested.
- Cross-domain: same protocol on data center, microgrid, biological system? Domain-agnostic in principle.
- Scale: 2-4 agents proven. 50+ is different problem entirely.

### Can the grand vision be reached?
The grand vision: living, self-maintaining coupling model of any complex system.
- Detection rung: real and solid.
- Characterization: achievable from existing data + engine work.
- Composition: the cliff. If edges don't compose, vision narrows to "snapshot tool." Still valuable but smaller.
- Scale: open research question. Scan rate vs. drift rate. Nobody knows the answer.

Current engine is a research prototype that proved the concept. Not the engine that reaches the vision. The Wright Flyer wasn't a 747. But it proved flight was real.

Paper 1 on arXiv changes the equation — attracts collaborators, funding, people who can test composition, scale, cross-domain.

## LinkedIn Article (draft, post when arXiv live)

Don't frame as "climbing the causal ladder." Frame as coupling discovery through active probing. Short, punchy, one figure (sensitivity curve), link to repo.

## ORCID Keywords

cybernetics, active inference, perturbation-based discovery, systems tending, blind coupling discovery, agent-as-sensor, guardrail-bounded discovery, empirical dependency mapping, coupling-graph-guided steering, live-system characterization, complex systems, emergent behavior, feedback loops, system dynamics, distributed control

## Files

- Paper: `/projects/godon/papers/detection/paper/main.pdf`
- Sweep data: `/projects/godon/papers/detection/experiments/`
- Summary: `/projects/godon/papers/detection/summary.md`
- Engine flaw notes: `/projects/godon/docs/notes/session-2026-07-31-chain4-validated.md` (updated tech debt section)
- Pearl alignment: this file
- Coordination lifecycle design: `/projects/godon/papers/detection/experiments/notes-coordination-lifecycle.md`
- Non-destructive perturbation: `/projects/godon/docs/impulse-detection-design.md` (updated)
