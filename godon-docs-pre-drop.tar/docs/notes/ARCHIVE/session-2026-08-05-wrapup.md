> **ARCHIVED — superseded.** Kept for history only; do not treat as current.
> Current owner: `INDEX.md + engine-status.md + paper-status.md`. See `../INDEX.md` for the reading map.
> Historical session log. Source of this consolidation plan; durable items moved to engine-status.md and paper-status.md.

---

# Session 2026-08-05 — Wrap-up Notes for Next Session

## Paper Status
- Paper on HAL (awaiting DOI + moderation)
- arXiv endorsement pending (cs.MA primary, cross-list eess.SP, cs.SY, math.OC)
- Paper is clean: 12 pages, 2 figures, Linux Libertine, all "impulse protocol" naming
- ORCID: 0009-0005-7399-5584

## Task #1: Notes Consolidation (CRITICAL — do this first)
The docs/ directory is actively misleading. Multiple files describe abandoned approaches as current.

### Files to DELETE or mark ABANDONED:
- watermark-phase-design.md — watermark removed from code entirely
- sprt-and-interference-detection-roadmap.md — SPRT never implemented, abandoned
- impulse-detection-fundamental-assessment.md — recommends CUSUM, abandoned. CFAR was chosen
- detection-validation-report-june19.md — old metrics, abandoned methods
- detection-architecture-pickup-notes.md — superseded
- coupling-detection-statistical-methods.md — post-mortem of passive methods, archival only

### Files to UPDATE (contain superseded content):
- the-arc.md — detection protocol section describes watermark slots, prime periods, stack-and-threshold. Must be rewritten to describe impulse protocol + CFAR
- impulse-detection-design.md — still has `destructive: true` config examples (marked deprecated but still present)
- validation-sweep.md — superseded by papers/detection/summary.md
- linkedin-intro-draft.md — old framing (watermark injection)
- config-layer-and-assessment-addendum.md — contains NLnet/funding assumptions (corrected: NOT NLnet-funded), Talbi co-author speculation

### Consolidation target structure:
```
docs/notes/
  the-arc.md               ← CONSOLIDATED vision (rewrite detection section)
  engine-roadmap.md         ← NEW: tech debt + fixes + scaling questions
  paper-status.md           ← NEW: 3 papers, current state
  ARCHIVE/                  ← old session logs, superseded docs
```

### Key principle: one living document per topic. Everything else archival.

## Task #2: Engine Fixes (blocks experimentation)
1. Coordination table lifecycle — tag-based groups. Currently needs full reinstall per cell.
2. Windmill script caching — second-run trial tags lost. Root cause unclear.

## Task #3: Paper 2 (Characterization)
- Data exists in 21 detect.json files
- Needs: per-parameter resolution (single-param perturbation mode in IMPULSE_CALIB)
- DoE (fractional factorial) for efficient multi-param schedules
- Threshold calibration (median-aware statistics)
- Extract: sensitivity coefficient accuracy, recovery fraction, noise floor validation

## Task #4: Personal Profile
- cherusku.github.io — drop Pelican, replace with clean landing page (draft at /tmp/cherusk-landing.html)
- GitHub README — draft at /tmp/cherusk-readme-v5.md. Needs: cross-boundary framing, minimal resources, connectome arc table
- LinkedIn article — draft ready, post when arXiv is live

## MARL Assessment (for paper accuracy)
- Checked current MARL state. Original claims mostly correct: implicit, task-specific, non-transferable coupling knowledge
- BUT: don't position against MARL. They solve a different problem. Nobody occupies our space.
- Paper already says this correctly: "not causal discovery in the Pearl sense" → positioning is positive now ("parallel to Pearl")
- Don't add MARL to the paper. Not relevant.

## Composition Prediction (Paper 3 context)
- Leontief (1936) proves composition works for linear systems with known structure
- Power grid load flow proves iterative composition for nonlinear systems with known structure
- Nature composes effects through chains everywhere (physics, biology, ecology, economics, climate)
- Our question: do EMPIRICALLY DISCOVERED edges compose as well as specified ones?
- 5% measurement accuracy suggests they will for approximately linear systems
- Nonlinear boundary is an empirical question, same kind as detection floor

## Scan Rate vs Drift Rate (fundamental limit)
- Not addressed in Paper 1, correctly deferred
- "The method supports coupling discovery up to drift rate D" is characterization, not failure
- Needs configurable-drift bench to test — doesn't exist yet

## What NOT to do next session
- Don't claim MARL is inferior — different problem
- Don't add more to Paper 1 — it's done
- Don't push to arXiv without endorsement (use HAL DOI in the meantime)
- Don't commit docs/ to the repo
