# Session Notes — Sep 3, 2026: deadlock fixed & verified; the thin-map root cause found (self-curve exemption)

START HERE if you are the next agent. Everything below is verified against
code and logs unless explicitly marked open. Read #348 top-to-bottom first
(three comments tonight tell the story), then this file.

## TL;DR

1. **Deadlock fix (#200, breeder 0.161.0) — merged, restacked, VERIFIED LIVE.**
   Clean handoffs, zero starvation, first denial ever logged (and it was a
   *correct* fair-share deferral).
2. **The thin-map root cause is found and is NOT the deadlock:**
   the self-walk retirement verdict never consults the walker's own
   self-curve. main.rs:732 (converged = all *per_receiver* curves) and
   :735-744 (gaps union over *per_receiver*) — the self-curve is probed
   separately (main.rs:807) and is in neither. Parked receivers converge
   trivially → guard passes on bystander stillness → walk retires at
   ~3 points. Node-4 is the tail: its dial moves only itself, so its
   self-walk's receivers are ALWAYS flat → node-4 alone was always thin.
3. **P2's priced stopping worked and its proof curves stand.** The guard
   works for every curve in the union (receiver-side structure). The
   exemption is the self-curve. The Aug 26 "walker core not shipped" note
   refers to the unextracted abstraction — the stopping behavior IS shipped.
4. **Fix decided with cherusk: A+C** — (A) causal is the notebook: the walk
   consults causal's own gaps/curves instead of carrying in-RAM state;
   (C) sufficiency stopping on the curve under study. Plus: fold the
   self-curve's gaps/converged into the retirement verdict. Fairness
   revision (turn-fair vs budget-fair) parked as a sub-decision in the
   characterization design group.
5. **Benches stopped** (s47/s48 cancelled ~19:56Z) — the certification
   question moved to the design layer; re-dispatch after the fix.

## The night's run saga (so nobody re-derives this)

- 05:48Z cert-47 rerun (0.161.0, extended clock) — completed 09:53Z
  success. Verdict: pieces rich (42/42/42), gate 25/17, node-4 self-map
  3 pts → #348.
- Suspension of THE AGENT'S OWN BOX (~15:40–16:25) — NOT the OSUOSL VM.
  Fingerprint if ever needed again: same boot, no guest PM messages,
  silent 42-min journal gap, bench sims resumed mid-stride.
- Cancelled s47 (mid-walk suspension is not pausable — the walk phase
  dies and does not resume) + s48; re-dispatched; cancelled again after
  the state-loss discovery; benches stopped pending the fix.
- Runner listener wedged 3× on job cancellations (github-runner 2.335.1
  bug). Fix: `sudo systemctl restart github-runner-gh-runner` — queue
  drains immediately. Not every cancel wedges it; watch for
  "queued forever" after any cancel.
- helm upgrade FAILED on `godon-seeder` Job (immutable spec —
  BREEDER_VERSION env changed). Fix: `kubectl delete job godon-seeder
  -n godon --ignore-not-found`, then re-upgrade. Durable fix (workflow
  pre-step) still to file on godon-charts.
- **Upgrade ≠ restack.** The seeder skips EXISTING scripts — a helm
  upgrade preserving the Windmill DB does NOT deploy new breeder code.
  Script changes require the CLEAN SLATE reinstall
  (charts--reinstall-stack.yaml). This cost one wasted dispatch.
- **Record maps purged by cleanup**: cancelling a run triggers its
  `if: always()` Cleanup → `breeder purge --force` → causal curve purge.
  The 37-pt record map (5acf9b2a) died this way. RECOVERABLE from Loki
  tells (every probe's shift/bar is logged per level). Snapshot of the
  post-purge store: /tmp/curves_snapshot_20260903T195649.json on the box.

## The thin-map root cause (the #348 core) — code-level

For a self-walk (breeder walking its own param):

- causal main.rs:731-744 — retirement inputs:
  `converged` = ALL *per_receiver* curves converged;
  `gaps` = union over *per_receiver* gaps.
- main.rs:807-821 — the walker's OWN self-curve is probed separately
  (receiver_id = sender) and NEVER enters per_receiver → its gaps and
  converged are absent from the retirement verdict.
- Parked receivers are flat → converge instantly, zero gaps → the
  two-key guard (probe_coordinator.py:706-725, intact, shipped 5c47891)
  passes on bystander stillness → the walk retires at whatever prefix
  the ladder reached (3 pts in the historical runs).
- Node-4 is the TAIL: its dial moves only itself → its self-walk's
  receivers are always flat → node-4 alone was always thin. The source's
  walks had the whole chain as witnesses with real structure → priced
  stopping visibly worked for them (43-level walks stopping at
  receivers' sufficiency = the guard working as designed).

Why refinement "ever worked" despite amnesia: walks that got one long
uninterrupted invocation refined fine within it (the ladder is real).
The state loss only bites at invocation boundaries — and whether a
walker got a long stretch was luck. Deep map vs 3-pt map = shift luck.
Tonight's run measured that lottery: uniform full-ladder ≈ 46 points ≈
900 trials (half the budget) vs sufficiency ≈ 17 points.

## Misdiagnoses made tonight (so they stay dead)

1. "The walk stalled at 15:39:40" — it COMPLETED (converged, DONE
   15:41:23). The "stall" was the post-walk idle I watched.
2. "State loss alone explains thin maps" — incomplete: the retirement
   verdict ALSO ignores the self-curve (composing defects).
3. "Retirement beats coverage / guard not shipped" — the guard IS
   shipped (5c47891, on main) and fired correctly ("priced out: 0");
   it just consults curves that exclude the self-curve. And the Aug 26
   "walker core not shipped" note = the unextracted abstraction, not
   the stopping behavior.
4. "Hypervisor pause fingerprint" — built from a `head -6` truncated
   journal view across two separate time windows. The truth: the
   AGENT'S box was suspended; OSUOSL never froze. Verify clock/gap
   claims with full-window queries.
5. "Walk restarts every few minutes" — no. Restarts are rare and
   event-driven; tonight's live walks ran 40-79 min in single
   stretches. The 4-min pattern in the cancelled run was one walker's
   flow dying once.

## What shipped tonight

- godon-breeders#200 (merged, rebase) — demand=False on walk completion
  + denial diagnostics. Tag 0.161.0. Charts 0.44.6. Restacked 14:44Z.
- Verified live: clean handoff (demand cleared → next walker acquired),
  first production denial line (a correct deferral, fully named).
- Posted: #348 ×3 (evidence 5525036733, resolution 5525408009, morning
  read 5530717936, correction 5531482001), #346 verdict 5525036859.

## The fix still to write (agreed A+C, awaiting go)

1. Fold the self-curve into the retirement verdict: probe self-curve
   BEFORE building the retirement inputs; extend the gap union with the
   self-curve's gaps; fold its converged into the two-key check.
2. Persist the walk bookmark (measured levels + floor) across
   invocations — CoverageWalk is deterministic from (bounds, floor,
   measured), so restoring them resumes exactly. (May become redundant
   if (1) is done via causal-consults design — A: "causal IS the
   notebook": walker asks causal for its curve's priced gaps each step.)
3. Then: re-dispatch s47/s48 → node-4's map depth = certification →
   rows unblock → P3.

## Open / parked

- Fairness revision (turn-fair vs budget-fair) — sub-decision in the
  characterization design group. Tonight priced uniform-vs-sufficiency:
  ~46 pts ≈ 900 trials vs ~17 pts. Data in #348.
- Durable workflow fix: delete godon-seeder Job pre-upgrade (one line,
  godon-charts PR, not filed).
- Convergence-based cell end (stop burning ~2h post-walk budget) — only
  safe after the fix, else it freezes thin maps. Design lever, priced
  tonight.
- P3 sentence check: if the text claims "walks stop at sufficiency"
  generally — scope it to receiver-side sufficiency or land fix 1 first.
  (The composition claim, P1, P2, and the honesty boundary are
  unaffected — the affected rows were already excluded.)

## Access quick-copy (verified tonight)

- ssh: `ssh -i /tmp/openstack_key godon@140.211.166.29`, KUBECONFIG
  /tmp/kind_kubeconfig.yaml. Read-only via `kubectl get --raw` pod-proxy.
- causal curves: pod godon-godon-causal-*: **8091** /proxy/curves
  (the SERVICE port 9091 ≠ container port 8091; api pod :9090 refused —
  connection refused, wrong listen port).
- Loki: pod-proxy godon-observability-loki-0:3100, query_range with
  **start/end epoch-ns** for old windows (since+limit>5000 → BadRequest;
  default direction = newest-first → old windows fall off — use
  direction=forward).
- gh: mint via `sh /tmp/mint.sh`, then `env -u GH_TOKEN gh api ...`
  (REST works; GraphQL 401s on the app token; token expires ~1h).
- Runner wedge: `sudo -n systemctl restart github-runner-gh-runner`.
- Log pulls: job logs of IN-PROGRESS runs are not served (empty);
  completed runs serve full logs. Job-log grep for uuids misses
  coordinator lines (they carry no uuid — attribute via COORD
  breeder= fields instead). CHAR TELL:* lines name the RECEIVER.
  tell `z=1.000` = first-probe neutral, NOT a walk verdict.
