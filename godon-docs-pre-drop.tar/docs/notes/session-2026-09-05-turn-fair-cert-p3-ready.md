# Session Notes — Sep 5, 2026: turn-fair acquire shipped; first clean 4/4 certs; P3 measurement campaign COMPLETE

START HERE if you are the next agent. The next session is for **writing paper P3**
(composition). The measurement campaign is DONE. Everything below is verified
against code, logs, and Loki unless marked open.

## TL;DR

1. **Turn-fair acquire shipped (breeder 0.163.3, PR godon-breeders#207):** the
   map-state need-defer veto (`_defer_to_needier_peer`) is deleted. Acquire
   ordering is purely the role ledger (`acquire_count`) + quantum yield
   (3 completed slices). Rationale: the veto's quantity self-masks (starved
   breeder = thin map = zero priced need), it fetched `/curves` on every
   acquire tick, and it was provably inert where it mattered (smoke: 0.0 vs
   0.0). This matches the turn-fair agreement — the ledger already existed;
   the veto sat in front of it and was removed.
2. **First clean 4/4 certifications in engine history:**
   - **s47** run 33968683471 (cliff, seed 47): GREEN 2h04m40s, terminal.
   - **s48** run 33974815211 (cliff, seed 48): GREEN 2h03m31s, terminal,
     chain-dispatched 2 s after s47.
   - 4/4 breeders walked, 32/32 curves converged by the priced sufficiency
     stop, depths 6–12 pts/curve, zero errors, rotation verified event-by-event.
   - s48 forensically verified INDEPENDENT of s47 (fresh UUIDs, own Loki trail,
     curve values differ at common levels, own ladder). Contamination ruled out.
3. **Idle tail measured:** all walks DONE by 14:17Z (s47), run closed 15:26Z —
   **69 min/cell of park burn** (s48: ~60 min). Convergence NEVER ends a run:
   the bench timing budget (~2h for cliff) or the iteration cap does.
   Convergence-based cell end is the next lever, now priced (~1h/cell), and
   safe since 0.162 folded the self-curve into the retirement verdict.
4. **papers/ restructured:** P3 has a new home — `papers/composition/evidence/`
   (PR godon#353, UNMERGED, awaiting cherusk's validation). All
   composition-for-runs evidence moved there; characterization/ keeps only
   P2-era engine-validation rows (runs 24–29) + sweep/.
5. **P3 measurement campaign COMPLETE.** Remaining for submission: gate
   verdicts for tonight's cliff rows, house-style figures with final numbers,
   the writing itself, Zenodo bundle at submission.

## What shipped today (all merged)

| PR | Repo | Content |
|----|------|---------|
| godon-breeders#207 | godon-breeders | turn-fair acquire (veto removed); TestNeedDefer removed; 340 unit tests green |
| godon#352 | godon | trace filter + QUANTUM/ACQUIRE/denied/COOLDOWN/Acquired |
| godon-charts#264 | godon-charts | BREEDER_VERSION 0.163.3 |
| godon#353 | godon | **OPEN, unmerged** — cert s47 evidence bundle in papers/composition/evidence/ (19 files) |

Tags/charts: breeder tag `0.163.3` (commit 70957d3) → charts values 0.163.3 →
clean-slate reinstall 33966538777 success, seeder env verified `BREEDER_VERSION=
0.163.3`.

## The certification ledger (P3, final numbers)

```
door-chain   28/28 (4 seeds)            linear + nonlinear chain
junction     11/12 (seed 46)            converging junction
             20/22 (seed 47)
cliff        33/34 (cliff_v2, run 33623243676)
             seed 47 GREEN 2h04m40s     ← tonight (run 33968683471)
             seed 48 GREEN 2h03m31s     ← tonight (run 33974815211)
poly         12/12 ×2
depth bound  ≈2 nonlinear hops at σ=0.02
```

Seed matrix at handoff: cliff 3 seeds, junction 2, chain 4, poly 2.
**cherusk to confirm sufficiency** (junction at 3 = one more dispatch if wanted).

## s47 anatomy (the reference cell)

- 13:21:55Z dispatch → 15:26:35Z success. 4 breeders, cliff, 1 param.
- CHAR INIT 4/4 (13:23:32, 13:27:52 ×2, 13:32:54 — inits land at first tenure).
- Rotation: 13 acquires, 10 QUANTUM yields, 22 denials, handovers 3–7 s,
  strict alternation, waiter won every handover, ex-holders correctly denied
  at the door. One full tenure = 3 cycles ≈ 3.5–4.5 min.
- Walks retired: 436d392f 14:11:15, 6ccfaac7 14:14:49, f7b4b880 14:17:55
  ("DONE: released lease. Converged 1/1 params"; gaps priced out 19/9/19);
  bc12e3ee retired earlier (map frozen+converged from first snapshot; its DONE
  line is not in the keyword-filtered trail).
- Final maps: 436d392f 8 pts, 6ccfaac7 11, bc12e3ee 6, f7b4b880 11 (8 curves
  each = 2 obj × 4 receivers; self-curve included post-0.162).
- Idle tail 14:18→15:26: park/hold/optimize trials only.

## Misdiagnoses made today (keep them dead)

1. "s48 ran on s47's surviving data" — NO. Forensics: fresh UUIDs never seen
   in s47; curve values at common levels differ (max 0.50, mean 0.21 — reused
   data would be bit-identical); own Loki trail; own ladder (7/8/12/12 vs
   8/11/6/11). The confusion came from finding (3).
2. "The job-log flattened trace shows the run's events" — only partially: the
   export step's Loki query window is `now − (budget·60 + 900s)` → for a
   300-min dispatch it dredges ~6¼ h, including the morning smoke and other
   runs. s48's trace showed the 12:45 smoke's breeders (4da0a5b7/5e157d2d).
   **Open bug:** pin the window to run dispatch time. Loki-direct pulls are
   the ground truth until fixed.
3. "Pre-rotation engine did 9 gaps in 31 min" — wrong: run 33948921099 ran
   0.163.1 WITH rotation. There is no non-rotation baseline; don't compare
   against one.
4. "4th-walker starvation / handback race" — artifact of the filtered trace
   (pre-#352). The waiters were waiting their turn; rotation was fine.
5. "Cliff timing budget is 240m" — that's junction-gate. Cliff ≈ 120m from
   bench start (s47 closed 15:26Z ≈ bench start 13:23Z + 120m + export/poll).

## The two dispatch traps (both hit today)

- `scenario` input takes the BARE name (`cliff`); the workflow prepends
  `scenario-` itself → `scenario=scenario-cliff` dies in 17 s with
  `scenario-scenario-cliff/topology.yaml: No such file or directory`.
- `max_wait_minutes` is also the JOB timeout (not just the poll watchdog) —
  a dispatch below the cell's natural duration executes the run *and* marks it
  cancelled. Cliff 4-breeders cells need ≥300 min in current form (or the
  convergence-end fix, below).

## P3 writing state (for the next session)

- `papers/composition/evidence/` holds (PR #353, unmerged):
  `run33968683471_final_curves.json`, `run33968683471_rotation_trail.json`,
  `run33968683471_summary.json`, `cliff_v2_run33968683471_maps/rotation/
  depth.{png,svg}` (brand-styled engine-cert figures), plus the moved
  composition gate scripts/curves and the junction/cliff-v2 figures.
- **Tonight's figures are engine-cert plots, NOT the P3 gate figure.** The
  house style is `/tmp/cliff2_fig.py` + `/tmp/junction_fig*.py` (matplotlib,
  measured vs planted vs composed-prediction, "N/M within 2σ"). Planted truth
  for cliff is codified there: threshold fires at L=55.6, saturation carriers
  0.9/0.5/0.45, piece→ref→hop4 pick pattern, bench-char-N→UUID mapping regex
  from the runlog.
- **To do for P3 figures:** adapt the cliff2 machinery to
  `run33968683471_final_curves.json` and `run33974815211` (when banked) →
  gate verdicts (N/M within 2σ per panel) → house-style figures with final
  numbers. **Depth-6 scrutiny on bc12e3ee is part of this** — gate verdicts at
  test levels decide; do not rely on converged flags alone.
- Paper framing rules (essence.md/paper-status.md, binding): one method,
  measured boundaries; no MARL positioning; Pearl parallel not ladder; no
  super-novelty claim; coupling-shape-agnostic central; the sweep is
  characterization not pass/fail.
- New methods receipt available for P3's text: starved 47/48 (before) vs
  green fair-scheduled 47/48 (after) — the fairness fix certified by its own
  rows. Also the idle-tail measurement (69/60 min) if the cell-end fix lands.
- Zenodo bundle: cut from `papers/composition/evidence/` at submission
  (P1/P2 drill: DOI, ORCID 0009-0005-7399-5584, arXiv needs endorsement).

## Efficiency ledger (velocity program, for later)

Baseline banked: cliff cell = 2h04m (4 walkers, 0.163.3, fair-share).
- Measured lever: convergence-based cell end ≈ −1h/cell (parked Sep 3, safe
  now, priced twice tonight). Implementation: walk complete → breeder script
  exits (worker `_should_continue`), or workflow treats park-after-done as
  terminal. Small; touches breeder_worker.py + poll.
- Holstered: campaign parallelism (pure packaging — `group_id` already
  isolates coordination; blockers are fixed names `bench-generic`, ports
  8090/3100, one runner; the queued OSUOSL 2nd box is the infra answer).
  NOTE: campaign-level parallelism needs NO interference pricing — different
  physics worlds cannot pollute each other. Breeder-level parallelism (same
  world) DOES need the interference-pricing cell.
- Holstered: block sizes 10→3 (~3×, two-key guard referees), adaptive settle
  (~2×), predict-then-confirm (attacks the tail walker — the cell duration IS
  the tail's duration; every cell has one).
- Doctrine settled today: breeders auto-tune sampling parameters (knobs →
  reflexes; the two-key check referees the tuner itself); the co-pilot does
  campaign-level judgment only (agent = minimal actuator, never the spine).

## Local repo states (so nothing surprises you)

- `/projects/godon`: branch `evidence/cert-s47` checked out (PR #353, unmerged).
  Untracked locals untouched: `.github/workflows/loki-diag.yml`, `.gitignore`,
  `AGENTS.md`, `_github/`. Tracked tree clean.
- `/projects/godon-breeders`: branch `fix/need-defer-publish` (ahead 1 =
  66d46bd, content-equivalent to merged main 70957d3). Phantom mode-changes
  on 25 files were chmod'd back to 644 (cherusk-approved). Untracked:
  `.claude/`, `ROADMAP.md`. `origin/main` = 70957d3 (turn-fair).
- `/projects/godon-charts`: local main DIVERGED (stale — has unpushed dup
  commit 0dd39a0 "0.161.0"); origin/main is truth (1fb2a77, 0.163.3). Don't
  pull/reset; branch off origin/main when needed (that's what #264 did).
- docs/notes/session-2026-09-03-deadlock-fix-and-self-curve-exemption.md —
  predecessor file; still accurate on infra receipts.

## Access quick-copy (all verified today)

- Token: `bash /tmp/mint.sh` (~1h TTL; re-mint on any 401 — it WILL expire
  mid-watch).
- Loki (read-only, ground truth): `ssh -i /tmp/openstack_key godon@140.211.166.29
  "KUBECONFIG=/tmp/kind_kubeconfig.yaml kubectl get --raw
  '/api/v1/namespaces/godon-observability/pods/godon-observability-loki-0:3100/
  proxy/loki/api/v1/query_range?query={service_name=\"godon-breeders\"}...'"`
  with start/end in EPOCH-NS and `direction=forward`. Use narrow windows ≤1–2h
  or you dredge prior runs (see bug #2 above).
- Causal curves (live ground truth): pod-proxy
  `godon-godon-causal-<id>:8091/proxy/curves` (container port 8091).
- Job logs of IN-PROGRESS runs are not served (empty 215-B responses) —
  completed runs only, or Loki meanwhile.
- The workflow trace filter now carries QUANTUM/ACQUIRE/denied/COOLDOWN
  (#352) — but the Loki window bug (open) can still pollute it with older
  runs' events; verify surprising traces against a direct Loki pull.
- Runner wedge after cancellations: `sudo -n systemctl restart
  github-runner-gh-runner` (didn't trigger today; keep in pocket).

## Open / parked

1. **Convergence-based cell end** (−1h/cell, measured) — implementation not
   written. Worker exit on walk-complete OR workflow poll reads parked-done as
   terminal. Small; do before the next cert campaign.
2. **Loki export window bug** — pin START to run dispatch (one line in
   bench-characterization.yml export step).
3. **Gate figure for cliff-47/48** — adapt /tmp/cliff2_fig.py; the P3
   validation plot cherusk expects.
4. **Depth-6 check on bc12e3ee** at gate-verdict time.
5. **Seed matrix sign-off** (junction at 3 seeds?) — one dispatch if yes.
6. **Interference-pricing cell** — the physics question that decides whether
   breeder-level parallelism (same world) is licensable; distinct from
   campaign parallelism (already safe).
7. PR #353 merge after cherusk validates the bundle.
