# Session 2026-08-10: Characterization Loop — Built, Merged, Needs Rework

## What was built and merged

### Merged PRs (all tagged, on main, deployed)

- **godon-breeders #181** → `0.145.0`: ProbeCoordinator + characterization.py
  - Replaces DetectionCoordinator (1228 lines, extremistic top-3 push) with ProbeCoordinator
  - characterization.py: ResponseCurve math (piecewise interpolation, convergence delta)
  - 22 unit tests (5 characterization math, 17 coordinator logic)
  - breeder_worker.py: wired to ProbeCoordinator, receiver observation writing, trial duration tracking, probe trial tagging

- **godon-images #270** → causal `0.5.0`: /characterize endpoint + probe_curves.rs
  - probe_curves.rs: ResponseCurve + CurveRegistry (Rust port)
  - trial_reader.rs: read_receiver_observations method
  - POST /characterize: real-time shift computation + curve update + convergence check

- **godon #305**: bench scenario (threshold topology, param_1 carrier)
  - + target configs, merged via rebase

- **godon-charts #234**: version bumps (breeder 0.145.0, causal 0.5.0)

- **godon #306**: bench-characterization.yml workflow (merged)

### Deployed on runner
- Stack reinstalled (clean slate) with new images
- Runner updated (nixos channel → github-runner 2.335.1, docker insecure permit, reboot)
- Bench workflow dispatched but NOT yet successfully completed — target creation was failing (post-reboot Windmill seed issue), reinstall was triggered to fix

## THE CRITICAL DESIGN FLAW — must be fixed next session

The coordinator I built uses a **deterministic for-loop schedule**, NOT the TPE-backed separate Optuna study we agreed on. This is wrong.

### What was agreed but NOT implemented

1. **Separate Optuna study for characterization.** The worker has one study (optimization). No second study was created. The characterization study with delta as objective does not exist.

2. **TPE samples discrete levels.** The strain already supports `trial.suggest_float(param, lower, upper, step=step)`. TPE should pick which config to probe. Instead I hardcoded `_build_probe_schedule()` as a for-loop.

3. **Delta as characterization study objective.** Causal computes the interpolation delta. That delta should be told back to the characterization study via `study.tell(trial, delta)`. TPE concentrates where the surface moves. I never wired this.

4. **Convergence_threshold reconfigures the study's step size.** The threshold should derive the step for `suggest_float`. I built `_derive_initial_step()` but it feeds a schedule, not Optuna.

5. **Short-lived sequential studies for refinement.** Cannot change step mid-study (confirmed from Optuna 4.9.0 source: `IntersectionSearchSpace` drops params with inconsistent distributions — "parameters with dynamic value ranges are excluded"). The correct approach: create a study with fixed step, run to convergence, close it, create a new study at half the step. Causal's ResponseCurves persist across studies — they ARE the memory. No Optuna trial migration needed.

### What exists in the coordinator that must be removed

- `_build_probe_schedule()` — deterministic for-loop schedule
- `_derive_initial_step()` as a schedule builder (keep the math, repurpose for study step)
- `_generate_halved_levels()` — schedule appending, wrong mechanism
- `_check_param_complete()` — halting should come from study convergence
- `_skip_to_next_param()` — convergence skip should be the study not sampling that region
- `_probe_schedule`, `_probe_idx` — schedule state

### What exists that is CORRECT and should be kept

- Coordinator push/pause/hold state machine (OPTIMIZE → PROBE_PUSH → PROBE_PAUSE → DONE → COOLDOWN + HOLD)
- Lease/heartbeat/turn-taking infrastructure (proven, unchanged)
- Causal /characterize endpoint (Rust, compiled, deployed)
- Causal CurveRegistry (probe_curves.rs) — owns all curves
- Receiver observation sharing (receiver_observations table + worker writing)
- Adaptive timeout deskew (tested: scales with trial duration, tightened by RTT)
- characterization.py ResponseCurve math (5 tests pass)
- Step derivation math (float + int handling)
- Trial tagging (probe_param, probe_param_idx, probe_level)
- Trial duration tracking in worker

### The correct design (for next session)

**Disposable studies, persistent curves.**

```
1. Coordinator enters characterization mode
2. Create Optuna study with step = convergence_threshold-derived step
3. TPE samples a config via trial.suggest_float(param, low, high, step=X)
4. Coordinator wraps sampled config in push/pause/hold
5. After pause block: causal /characterize computes shift + delta
6. study.tell(trial, delta) — TPE learns where the surface moves
7. Coverage guard: first N trials visit all params (enqueue_trial or manual)
8. When study's best delta < convergence_threshold → close study
9. Ask causal: any param not converged at this resolution?
10. If yes and refinement passes remain: create new study at half step, goto 3
11. If all converged or refinement_depth exhausted → DONE
```

**Key insight**: Causal's CurveRegistry persists across studies. The studies are disposable probes. The curves are the product.

**refinement_depth** = max number of sequential studies
**convergence_threshold** = step derivation + study halting

## Other open items

### From characterization-strategy.md

- **#0 (VITAL)**: When to optimize vs characterize switching. Current coordinator switches once (OPTIMIZE → probe → DONE → OPTIMIZE). Real systems need: interleave, maintenance-triggered rescan, possibly parallel. NOT defined.
- **#0b**: Categorical params. Piecewise interpolation requires orderable continuous levels. Categoricals need different treatment (lookup table, not curve). Deferred.
- **#4 RESOLVED**: Feedback signal is interpolation delta (not coupling response magnitude). Causal /characterize computes it. Triple duty: sampler objective + halting + drift detector.

### Bench validation
- Bench workflow exists but hasn't completed successfully yet
- Post-reboot Windmill seeding issue (not our code)
- Reinstall was triggered to fix
- Once stack is stable: re-dispatch bench-characterization workflow
- First run with deterministic schedule will validate the protocol
- TPE-backed rework comes after

### Naming
- `probe_coordinator.py` / `ProbeCoordinator` — the coordinator (measurement orchestration)
- `characterization.py` — ResponseCurve math
- Causal `/characterize` endpoint — real-time curve update

### Files changed across repos

**godon-breeders (0.145.0):**
- `engine/probe_coordinator.py` (1104 lines) — coordinator (NEEDS REWORK)
- `engine/characterization.py` (335 lines) — ResponseCurve math (KEEP)
- `engine/breeder_worker.py` — wired to ProbeCoordinator
- `engine/detection_coordinator.py` — DELETED
- `tests/unit/test_characterization.py` — 5 tests
- `tests/unit/test_probe_coordinator.py` — 17 tests (WILL NEED REWRITE for TPE approach)
- `tests/unit/conftest.py` — Windmill import stubs
- `tests/analysis/analyze_characterization.py` — post-hoc analysis script

**godon-images (causal 0.5.0):**
- `images/godon-causal/src/probe_curves.rs` (190 lines) — ResponseCurve + CurveRegistry
- `images/godon-causal/src/main.rs` — /characterize endpoint
- `images/godon-causal/src/trial_reader.rs` — read_receiver_observations

**godon:**
- `examples/bench/scenario-characterization/` — topology + breeder configs + targets
- `.github/workflows/bench-characterization.yml` — bench workflow

**docs (local only, NOT committed):**
- `docs/notes/characterization-strategy.md` — updated (delta correction, open questions)

### Customer-facing config
```yaml
interference_detection:
  group: bench-characterization
  convergence_threshold: 0.02    # precision → derives step size
  refinement_depth: 3            # max sequential studies
  hold_params:
    param_0: 50.0
```

### Access
- SSH: `ssh -i /projects/godon/openstack godon@140.211.166.29`
- KUBECONFIG: `/tmp/kind_kubeconfig.yaml`
- GitHub token: `/tmp/gh_token.txt` (regenerate via JWT→installation token)
- Bench workflow: `https://github.com/godon-dev/godon/actions/workflows/bench-characterization.yml`
