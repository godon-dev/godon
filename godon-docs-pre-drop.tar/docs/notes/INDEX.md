# Godon docs — Index & Reading Map

Internal notes. **Start here.** This index states the current resolved framing
and points to one owner per topic. Superseded material lives in `ARCHIVE/`
with banners — do not trust it as current.

For the 2-page distillation of what godon is, read `essence.md` next.

---

## Quick status (as of Aug 2026)

- **Paper 1** ("The Impulse Protocol: Non-Destructive Coupling Discovery in
  Autonomous Agents") — done. Zenodo DOI 10.5281/zenodo.21962956 (also on
  HAL, awaiting moderation); arXiv pending endorsement. 12 pages,
  2 figures. See `paper-status.md`.
- **Detection** — proven. 21-cell sweep + chain4 edge validation. Zero false
  positives. Boundary characterized honestly.
- **Composition** — **PROVEN.** Linear (chain4, Aug 8); nonlinear wave
  Sep 2: door-chain 28/28, junction, live-discontinuity cliff 33/34.
  Boundary: ~2 nonlinear hops at σ=0.02. See session-2026-09-02 notes.
- **Code:** godon-causal 0.3.7, breeder 0.141.0, bench-generic 0.1.0
  (see `engine-status.md`).

## Reading order for a fresh session

> **Current phase: post-P3.** P3 PUBLISHED Sep 5, 2026 — *From Curves to Cascades*, Zenodo
> 10.5281/zenodo.22401439 (95/97 referee points; horizon ≈2 nonlinear hops at σ=0.02). Docs site
> flipped Sept 6 (godon-documentation PRs #114–#117: publications, status pages, contributing,
> blog notes). Next rung: the steering number (optimum with vs without coupling edges) and
> live-B. Campaign record: `session-2026-09-05-turn-fair-cert-p3-ready.md` (measurement
> COMPLETE, first clean 4/4 cliff certs s47+s48, turn-fair 0.163.3, evidence banked in
> `papers/composition/evidence/` via PR #353); P3 plan: `session-2026-09-02-p3-plan-and-handover.md`;
> then the owners below.

1. **`essence.md`** — the distillation. States the resolved positioning
   definitively and the PROVEN / DESIGNED / SPECULATIVE stratification.
2. **`the-arc.md`** — the full 7-step vision. (The "Detection Protocol"
   section was rewritten this pass to the shipped impulse + CFAR method.)
3. **`causal-roadmap.md`** — current architecture, method, milestones,
   tractability. The engineering reference.
4. **`engine-status.md`** — shipped versions, tech debt, blockers.
5. **`paper-status.md`** — the three-paper plan and current state.

**Reference (doesn't go stale):**
- **`intellectual-lineage.md`** — the thinkers/fields converging at godon's
  position.

**Retained for detail (current, but partially overlapping the owners above):**
- **`causal-session-architecture-and-reframing.md`** (Jul 24) — the detailed
  L1-L11 / U1-U9 / S1-S6 stratification. Useful reference; its durable points
  are reflected in `the-arc.md` and `causal-roadmap.md`.

**Formal-domain track (downstream of infrastructure work):**
- `causal-models-for-formal-systems.md` + `code-validation-ground.md` — the
  code/text extension of the artifact thesis. Valid direction, clearly
  downstream. Code is proposed as the fastest place to prove the composition
  keystone (deterministic composition is exact).

## Topic → single owner

| Topic | Owner | Status |
|---|---|---|
| What godon is, resolved positioning, the bet | `essence.md` | done |
| Reading map, archive audit trail | `INDEX.md` | done |
| Full vision + 7-step arc + stratification | `the-arc.md` | done (detection section corrected) |
| Current architecture, method, milestones | `causal-roadmap.md` | current (some duplicated vision, low harm) |
| Shipped versions, tech debt, blockers | `engine-status.md` | done |
| Paper plan + status | `paper-status.md` | done |
| Intellectual lineage | `intellectual-lineage.md` | keep as-is |
| Code/text formal-domain extension | `causal-models-for-formal-systems.md` + `code-validation-ground.md` | keep |

## Archive audit trail — what was superseded and why

Everything below now lives in `docs/notes/ARCHIVE/` with a banner naming the
current owner and the reason. Nothing was deleted. Raw content is intact.

**From `docs/notes/` (superseded by the owners above):**
- `the-living-connectome.md` → essence + the-arc. Early vision; "completing
  Friston" stance superseded by Branch B.
- `vision-and-strategy.md` → essence + engine-status. Early roadmap.
- `the-artifact-thesis.md` → essence. Branch B conclusion adopted; this is the
  reasoning trail.
- `config-layer-and-assessment-addendum.md` → essence. **Warning: contained
  wrong assumptions** (godon is NOT NLnet-funded; Talbi co-author was
  speculation). Banner flags this.
- `session-2026-07-27-29-debugging.md`, `session-2026-07-31-chain4-validated.md`,
  `session-2026-08-01-detection-paper-scoping.md`, `session-2026-08-04-paper-and-vision.md`,
  `session-2026-08-05-wrapup.md` → engine-status + paper-status. Historical
  logs; durable content distilled into the owners. The Aug 5 wrapup was the
  source of this consolidation plan.

**From `docs/` root (abandoned approaches):**
- `watermark-phase-design.md` — watermark removed from code entirely.
- `sprt-and-interference-detection-roadmap.md` — SPRT never implemented.
- `impulse-detection-fundamental-assessment.md` — recommended CUSUM; **CFAR
  was chosen instead.**
- `detection-validation-report-june19.md` — old metrics; superseded by
  `papers/detection/summary.md`.
- `detection-architecture-pickup-notes.md` — superseded.
- `coupling-detection-statistical-methods.md` — post-mortem of failed passive
  methods; archival reference.

## Still in `docs/` (root) — not archived, not current work

These are shelved design docs or superseded-but-not-abandoned. Left in place:
`convergence-detection.md` (Status: Shelved), `context-aware-samplers.md`,
`hidden-effects.md`, `stasis-patterns.md`, `gui-dashboard.md`,
`impulse-param-selection.md`, `detection-coordination.md`,
`detection-rounds-schema.md`, `category-and-market.md`,
`strategic-analysis-notes.md` (positioning — superseded by essence.md),
`impulse-detection-design.md` (still has deprecated `destructive: true`
examples), `validation-sweep.md` (superseded by papers/detection/summary.md),
`linkedin-intro-draft.md` (old framing), `doc-rework-pickup-notes.md`
(concerns the *public* docs in godon-documentation/, paused — separate
concern). Plus 5 HTML visualization prototypes (visualization is explicitly
deferred).

## Consolidation status

- [x] `INDEX.md`, `essence.md` drafted
- [x] Rewrite `the-arc.md` "Detection Protocol" section → impulse + CFAR
- [x] Create `engine-status.md` from session wrapups
- [x] Create `paper-status.md`
- [x] Move superseded files to `docs/notes/ARCHIVE/` with banners (15 files)
- [x] Resolve the old "completing Friston" framing — archived docs carry banners
- [ ] Trim duplicated vision/positioning from `causal-roadmap.md` (deferred —
      low value, low harm; the doc is current and usable as-is)
