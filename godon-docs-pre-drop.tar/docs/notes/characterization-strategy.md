# characterization strategy — experimental

STATUS: design discussion outcome (Aug 9 session). Nothing implemented.
Every claim below is a hypothesis to be tested on the bench. This is NOT
a specification — it is the result of circumferencing the problem from
multiple angles until a coherent shape emerged. The shape may be wrong.
The bench will tell us.

## context: what broke

detection is proven — 21-cell sweep, A/B verified, CFAR, zero false
positives at coupling=0.0. composition validated — 3-hop linear, 9%
error. the impulse protocol works. CFAR works. the coordinator
turn-taking works.

but ALL validation assumed we KNEW which params carry coupling. the
extremistic push (top-3 by range, slam to wall) only works when the
right params are in the top-3. on a 50-param system where coupling
lives in params 7, 19, 34 — the heuristic pushes dead params. coupling
exists but is never triggered. false negative. detection fails silently.

this means: the detection results validate the PROTOCOL (push/hold/
pause, CFAR, coordination), not the PROBE STRATEGY (which params to
push, at what level). the probe strategy is the open problem.

## the core realization

detection and characterization are not separate phases. they are the
same activity at different completeness:

- detection = "found at least one carrier param"
- characterization = "found them all, measured their response shape"

you can't detect without finding carriers. you can't characterize
without detection. the split was an artifact of the extremistic
heuristic — it pretended you could detect first (big push) and
characterize later (per-param). but the big push only works if it hits
the right params. whether it hits the right params IS the
characterization question. remove that assumption and the split
collapses.

one process: probe configs, measure receiver response, concentrate
sampling where response is strong, discover carrier params, measure
their response shape, halt when shape stabilizes.

## rejected approaches and why

### 1. extremistic push (top-3 by range, slam to wall)

current heuristic. misses coupling carriers on unknown systems. all 21
sweep cells validated detection only where we knew which params carry
coupling. for 50-param systems, pushes dead params, false negative.

### 2. separate detection and characterization phases

collapsed — see core realization above.

### 3. flatness search for receiver calibration

optimizes the wrong metric. quiet ≠ responsive. drifts toward death
(system with mean→0 is perfectly flat). the aliveness check (mean > 0.1)
was a patch on a wrong objective. deployed workaround: manual hold_params
in config bypasses calibration entirely.

### 4. metaheuristic for characterization without halting

no stopping criterion. runs forever. concentrates where signal lives
but never says "enough." characterization is open-ended and intractable
without halting.

### 5. DoE (fractional factorial, DSD) as primary method

batch-oriented. can't halt early without breaking the design's
mathematical guarantees (orthogonality, alias structure). can't insert
substeps mid-design without redesigning from scratch. if a linear edge
needs 3 points but the design has 8 runs — 5 wasted. the fixed schedule
fights adaptive stopping.

DSDs (definitive screening designs, 2k+1 runs) detect main effects,
quadratic curvature, and two-factor interactions in one pass — but
assume ~2nd-order polynomial. software coupling (thresholds,
discontinuities) violates this assumption. and the batch structure
still fights halting.

DoE's strength — guaranteed orthogonal coverage in fixed runs — becomes
a liability when you need adaptive stopping.

### 6. compressive sensing / sparse regression

no mathematical guarantee for coherent polynomial bases. the RIP
condition breaks for dictionaries where basis functions (x, x², x·y)
are nearly collinear over a compact box. works empirically only under
true sparsity with incoherent design. silent wrong answers for
interaction bundles.

### 7. model-form fitting (assume linear / polynomial / threshold)

mis-specified model never converges. fitting linear to threshold data:
each new point shifts the slope. the model form is what you're trying
to DISCOVER, not assume.

### 8. noise-floor-based halting (prediction error vs MAD)

one held-out point is a coin flip. MAD at one operating point doesn't
represent noise across the curve. model mismatch plateaus above floor
and never crosses it → runs forever.

### 9. cross-validation halting (leave-one-out)

more stable than single held-out but still tied to noise floor. doesn't
directly measure function convergence. extra complexity for indirect
signal.

## what we settled on (EXPERIMENTAL — untested)

### probe selection: optuna with discrete steps

the config constraints already support step sizes:
  trial.suggest_float(param, lower, upper, step=step)

steps define characterization resolution (how many levels per param).
the sampler (TPE) decides ORDER — concentrates where coupling response
is strong. sequential, not batch.

coverage guard: first N probes cycle through all params once before
the sampler takes over. prevents the sampler from skipping a param
entirely before every param has been probed at least once.

after the guard, the sampler can't permanently skip a level because
it's a bounded discrete set. it visits them probabilistically —
eventually all, with bias toward informative ones.

the value told back to the sampler: interpolation delta — how much the
modeled response surface moved when the latest point was added. NOT
coupling response magnitude (which biases toward flat regions above
threshold). NOT growth_rate. the interpolation delta is self-referential:
it concentrates sampling where the function is CHANGING, not where the
response is HIGH. this makes it a triple-duty signal: sampler objective,
halting criterion, and drift detector (persistent nonzero delta means
the system is non-stationary).

### characterization: piecewise interpolation, no model form assumed

measured points at each visited level. piecewise interpolation through
them. no fitting equation. the measured data IS the function.

works for all response shapes:
- linear: straight line, converges fast
- threshold: steep segment in interpolation, refined by substeps
- saturation: bend visible in interpolation
- discontinuous (software): jump visible in interpolation

the shape EMERGES from the measurements, not from an assumed equation.

### halting: interpolation convergence

after each probe, compare the new interpolation to the previous one.

- function barely changed → converged → halt this edge
- function shifted significantly → keep going
- function stuck (error plateau) → recursive substep where curve moves most

convergence is: adding a new measured point doesn't significantly
change the interpolated surface. this is function precision, not noise
precision.

recursive substeps: if convergence fails between two adjacent levels
(the curve is still moving there), insert an intermediate level.
probe it, refit interpolation, recheck convergence. recurse until
stable.

### receiver calibration: pragmatic midpoints

midpoints by default. if zero detection after full coverage pass →
try alternative hold point. 2-3 retries max.

does NOT solve the quiet-but-unresponsive problem (hold point where
coupling signal arrives but receiver is insensitive). pragmatic
mitigation: the maintenance loop catches missed edges through
prediction error during operation.

### detection happens naturally

first level producing coupling response above CFAR threshold = detection.
no separate detection phase. the same loop that characterizes also
detects — the first measured point above threshold IS the detection event.

## the one loop

probe (optuna with steps) → measure (receiver holds, sender pushes at
sampled level) → detect (CFAR on receiver shift) → interpolate (add
point to response surface) → check convergence (did the surface move?)
→ halt or probe next level.

one loop. detection, characterization, and halting are natural phases
of the same activity, emerging from trial count and measured response.

## what is genuinely open (honest)

0. WHEN to characterize vs WHEN to optimize — and whether they can run
   in parallel per breeder. the current coordinator switches once
   (OPTIMIZE → PROBE → DONE → OPTIMIZE) and never switches back. real
   systems need: interleave (optimize, characterize, optimize from what
   was learned), maintenance-triggered (operate from frozen model,
   rescan when prediction error spikes), and possibly parallel (some
   breeders probe while others optimize). NOT defined. VITAL — noted
   for future design.

0b. categorical params — the characterization approach (piecewise
    interpolation, convergence delta, refinement) requires orderable,
    continuously-valued levels. categorical params (enum strings, mode
    switches) are unordered — no distance, no interpolation, no curve.
    they need a different treatment: probe each value once, measure
    shift, build a lookup table not a response curve. NOT implemented.
    deferred until a real system needs it. float and int are handled.

1. whether optuna's TPE sampler with discrete steps actually visits all
   levels reliably enough. TPE is designed for optimization, not
   coverage. it biases hard toward good regions. with steps it can't
   skip permanently, but it might deprioritize one for a long time.
   UNTESTED.

2. whether interpolation convergence is stable under noise and drift.
   non-stationary systems might cause the function to keep moving
   even when characterization is sufficient — false "keep going."
   UNTESTED.

3. whether the quiet-but-unresponsive receiver problem causes
   systematic false negatives. pragmatic mitigation (retry hold points)
   might not suffice. UNTESTED.

4. the feedback signal: interpolation delta (how much the modeled
   response surface moved) must reach the sampler. RESOLVED (Aug 10):
   the signal is interpolation delta, not coupling response magnitude.
   delta concentrates sampling where the function changes most — correct
   for interpolation. triple duty: sampler objective + halting criterion
   + drift detector. the infrastructural gap remains (receiver's measured
   shift must reach the sender's ResponseCurve), but the SIGNAL is now
   defined. the ResponseCurve module exists and is tested.

5. whether this works for software coupling (thresholds, discontinuities,
   state-dependent coupling). the interpolation approach is form-agnostic
   in principle. but software coupling might be pathological in ways the
   bench doesn't capture.

6. whether 50-param screening with optuna + steps is tractable. for 50
   params × 5 levels = 250 discrete combinations. the sampler explores
   this adaptively, but convergence time is unknown.

## relationship to existing roadmap

this strategy is milestone 4 (characterization protocol) from the
causal-roadmap, but with a specific mechanism chosen. the roadmap said
"metaheuristic-driven sampling with hold-and-measure" — this specifies
WHICH sampling (optuna with steps), WHAT halting (interpolation
convergence), and WHAT characterization (piecewise interpolation, no
model form).

the roadmap's tractability degradation (lines 528-553) still applies:
start with the cheap approach (coverage pass), check prediction, only
escalate (decomposition, bundles) where prediction fails. the
characterization strategy here IS the cheap approach. decomposition and
bundle identification remain as escalation when prediction error
demands them.

## first step

the bench run. 3 params, threshold base function, discrete steps in
config. ground truth tells us immediately:
- does the sampler visit all levels?
- does the protocol measure clean points at each level?
- does interpolation recover the threshold shape?
- does convergence halt correctly?

one workflow dispatch. uses existing infrastructure. validates or kills
the approach on the easiest possible case.

## what does NOT change

the impulse protocol. one pushes, others hold, CFAR detects the step.
this is proven, form-agnostic, and NOT in question. everything above
is INSIDE the protocol — replacing the probe strategy and adding
characterization + halting. the protocol itself is untouched.
