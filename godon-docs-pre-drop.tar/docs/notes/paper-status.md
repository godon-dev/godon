# Paper Status

Internal — not published. The three-paper plan and current state. For the
engine that produces the data see `engine-status.md`; for positioning see
`essence.md`.

## Paper 1 — Detection — DONE, do not touch

**Title:** "The Impulse Protocol: Non-Destructive Coupling Discovery in
Autonomous Agents"

- **Zenodo DOI (assigned, Aug 2026): 10.5281/zenodo.21962956**
  (https://doi.org/10.5281/zenodo.21962956) — the citable reference.
- Also submitted to HAL (awaiting moderation).
- arXiv pending endorsement — **cs.MA primary**, cross-list eess.SP, cs.SY,
  math.OC. Don't push to arXiv without endorsement; use the Zenodo DOI
  meanwhile.
- 12 pages, 2 figures (state machine, sensitivity curve), Linux Libertine,
  titlesec, parparsk.
- 21 cells of sweep data in results tables.
- ORCID: 0009-0005-7399-5584.
- Paths: `papers/detection/paper/main.pdf`,
  `papers/detection/summary.md`, data in `papers/detection/experiments/`.

The paper is clean and finished. Do not add to it.

## Paper 2 — PUBLISHED Aug 27, 2026

- **Zenodo DOI: 10.5281/zenodo.22127166** — title, ORCID verified.
- arXiv categories (for endorsement day): cs.MA primary;
  cross-list eess.SY, stat.AP, math.OC.
- PENDING: evidence-bundle file not yet on the record (main.pdf
  only); add as new version when zipped.

The sweep IS the paper. Sensitivity floor, noise-robustness boundary, topology
generalization, nonlinear coverage. Every grid cell is a calibration data
point.

**Data already collected** (21 `detect.json` files):
- Step amplitude accuracy: within ~5% across linear range.
- Noise floor: MAD tracks planted sigma closely.
- Shape-dependent behavior: saturation inverts, threshold jumps, polynomial
  compresses.
- Reversibility: falling_edge present for all detections (ABA holds).
- Sensitivity coefficient = `rising_edge / impulse_scale` — does it recover
  planted strength?
- Recovery fraction = `|falling / rising|` — when is coupling reversible vs
  hysteretic?

**Needs new engine work** (see engine-status §3):
- Per-parameter resolution (single-param `IMPULSE_CALIB` mode).
- DoE — fractional factorial perturbation schedules (3 params → 4
  combinations instead of 8). One-at-a-time is brute force; the impulse
  protocol IS a DoE problem, currently done the most basic way.
- Per-channel detector output.
- Param → channel mapping.
- Threshold calibration: CFAR uses per-sample MAD but compares block medians;
  Pfa=0.05 is not literal (actual false-alarm rate lower, conservative).
  Median-aware threshold would improve sensitivity but needs re-deriving false
  alarm statistics.

**Two fields most vital for progress:** Design of Experiments; statistical
calibration theory.

## Paper 3 — Composition — PUBLISHED Sep 5, 2026

- **Zenodo DOI: 10.5281/zenodo.22401439** — *From Curves to Cascades:
  Composed Coupling Prediction Among Autonomous Agents*. Concept DOI
  (resolves to latest version).
- Headlines: 95/97 referee points within propagated 2σ bars; the
  propagated bars validated as honest metrology; composition horizon
  ≈2 nonlinear hops at σ=0.02.
- Documentation flipped Sept 6 (godon-documentation PRs #114–#117:
  publications, status pages, contributing, blog update notes).
- Evidence bundle: deferred, same pattern as P2's PENDING — owed at
  first external ask.

Chain4 proved edges are measured correctly. **Composition PROVEN for linear**
(Aug 8, 2026): cascaded coupling in bench-generic + multi-hop predict in causal
+ true coupling coefficient (sender_delta-based). Result: predicted 0.0956 vs
planted 0.105 (9% error at 3 hops). See engine-status §"Composition".

Sep 2 update — nonlinear composition PROVEN (session-2026-09-02 notes
+ godon#346): door-chain 28/28 (4 seeds), junction 11/12 (seed 46) + 20/22
(seed 47), live-discontinuity cliff 33/34, poly shapes 12/12 ×2, depth
boundary ≈2 nonlinear hops at σ=0.02. Fair-scheduled junction seed reruns
in flight (certification rows; the starved 47/48 runs are the fairness
fix's before-receipts). All of it landed in the Sep 5 submission except
the evidence bundle (still deferred — first external ask, P2 pattern).
- **Diamond topology** — still open (transitive direct-edge
  characterization; scanner limitation, not a bug).
- **Optimum WITH coupling edges vs WITHOUT** — becomes the steering
  paper's core number (next rung after P3).

## Framing decisions (apply across all three)

- Diligence note (Aug 27): arXiv slice swept for the "to our
  knowledge" positioning (agent-coupling-calibration,
  intervention-causal-autonomous, coupling-live,
  optimizers-interference, adaptive causal discovery,
  grid probing). Nearest neighbor found: arXiv 2018 "Graph
  Algorithms for Topology Identification using Power Grid Probing"
  — centralized operator, boolean topology, no autonomous
  experimenters, no certified curves. Defensive phrasing holds.
  Journal-only literature residual noted; not blocking per
  cherusk's call.

- **No super-novelty claim.** Present as "one method, measured boundaries."
  Related work is context, not a wall. No exhaustive prior-art hunt.
- Components aren't new (CFAR is 1960s radar; ABA block design is classical;
  turn-taking is scheduling). Contribution is the specific assembly working
  as a deployable instrument with characterized limits.
- **Coupling-shape-agnostic is central** to Paper 1. Nonlinear coverage is
  not a side experiment — it's evidence for the core generality claim.
- The sweep IS characterization, not pass/fail. Report the boundary honestly.
  Do NOT tweak the detector during the sweep. Two failure types: (1) expected
  degradation (weak coupling at high noise) = the floor, report it; (2)
  unexpected failure (strong coupling at low noise) = debug, instrument broken.
  No minimum performance bar. Honest boundary > gamed pass rate.
- **Don't position against MARL** — different problem. Nobody occupies our
  space.
- **Pearl alignment — resolved (Aug 4):** the method runs **parallel** to
  Pearl's ladder, not on it. Pearl's experimenter is centralized + human; ours
  is distributed + autonomous. "Empirical coupling discovery" — a category
  nobody occupies. Paper already says this correctly.

## Known gaps in the current sweep plan

1. No systematic false-positive characterization across conditions. CFAR's
   central property is Constant False-Alarm Rate — empirically untested across
   conditions. Need genuinely uncoupled nodes (coupling=0.0) at each noise
   level. Non-edge pairs in a connected topology are NOT true negatives
   (indirect coupling = composition question).
2. No controlled passive-method comparison on synthetic data (optional —
   greenhouse already demonstrates passive failure, but synthetic is cleaner
   for a reviewer).

## What NOT to do

- Don't claim MARL is inferior — different problem.
- Don't add more to Paper 1 — it's done.
- Don't push to arXiv without endorsement.
- Don't commit `docs/` to the repo.
