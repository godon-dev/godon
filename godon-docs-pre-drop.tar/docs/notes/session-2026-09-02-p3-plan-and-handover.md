# Session Notes — Sep 2, 2026 (evening): P3 writing plan + handover

For the next agent. Current phase: **wave closed, P3 writing begins.**
Everything below is either done, in flight, or gated with the gate named.

---

## PART 1 — THE P3 WRITING PLAN

### The claim (one sentence)

Pairwise-measured coupling curves — measured locally, by autonomous
agents, referenced by protocol — **compose**: chained through nonlinear
doors, summed at converging junctions, they predict far-end behavior
without walking the chain, within propagated error bars.

### The one-line honesty frame

"One method, measured boundaries." Cascade identification is textbook
(Wiener/Hammerstein lineage) — the contribution is the **assembly**:
distributed, autonomous, behavioral measurement whose pieces compose
with priced uncertainty. No super-novelty claims. Related work is
context, not a wall. Do not position against MARL. Pearl is parallel,
not a ladder.

### Structure (section by section)

1. **Intro** — coupled autonomous systems; end-to-end identification
   dies at the noise floor; measuring neighbors and composing is the
   alternative. The measurement horizon (depth4) is the motivation.
2. **Related work** — block-oriented system ID (Wiener/Hammerstein:
   cascade ID is textbook — say it first, before a reviewer does);
   fair queueing lineage for the engine (Demers '89, DRR '95, CFS);
   empirical coupling discovery as the unoccupied category.
3. **The instrument** — agents that perturb, hold, and publish; parking
   protocol; lease turn-taking; the curve as currency; bars per point.
4. **The composition claim** — formal statement; the channel algebra
   ("level is level": label by total level, never by dial); referee =
   composed-vs-direct (pieces and referee are disjoint measurements);
   propagated bars from local noise, validated empirically.
5. **Results** — the evidence table below. Figures exist in
   `papers/characterization/evidence/` (junction_gate_*.png,
   cliff_v2_*.png); fair-seed versions of the junction fig after the
   certification runs.
6. **Boundaries** — composition horizon ≈ 2 nonlinear hops at σ=0.02
   (depth4: beyond it the far end falls below the floor and the referee
   goes vacuous — measured, not assumed); discontinuity coverage
   included (cliff-v2); excluded: memory/history doors, categorical
   inputs, drift — each named as the next rung, not hidden.
7. **Discussion** — why the horizon makes composition necessary; the
   map as system self-knowledge; transfer (M6) as prior-with-
   verification, one future-facing paragraph, gated by drift economics.

### The evidence table (run ids and numbers)

| Row | Run | Result |
|---|---|---|
| Linear 3-hop precedent | chain4 (Aug 8) | pred 0.0956 vs planted 0.105 (~9%) |
| Nonlinear chain, 4 seeds | door-chain s42–45 | 28/28 |
| Junction (convergence) | junction-gate s46 (33522428904) | 11/12, step exact at L=55.56 |
| Live discontinuity | cliff-v2 (33623243676) | 33/34; step −0.159 vs −0.161 (8σ); flip bracketed L53–56 |
| Poly shape validation | 33607018911 | 12/12 + 12/12, spans 30σ/18σ |
| Dead-plant salvage | cliff-v1 (33597128644) | piece 18/18 (worst z 0.61); no phantom firing |
| Depth boundary | depth4 (33558088446) | horizon ≈ 2 nonlinear hops; referee vacuous beyond |
| **Fair certification** | junction s47/s48 fair (33662964012 / 33662980408) | **in flight — lands tonight** |

Methodology claim to foreground: the **error bars compose too** —
propagated local-noise bars, validated against direct walks through
nonlinear chains. That is the metrology result; a metrology reviewer
will nod harder at it than at composition itself.

### Boundaries stated in the paper (the honest footnote list)

- Memoryless doors only (every receipt assumes the door answers the
  same way every ask). Memory/history = next tier.
- Dial inputs only (continuous). Categorical switches = future.
- Static planted world. Drift/motion = future.
- Multi-walker runs ran under timing/budget overrides with a
  lease-fairness fix shipped mid-campaign (breeder 0.159.0,
  fair-share turn counts); certification rows use fair scheduling.
- Composition horizon measured at σ=0.02, saturation-family doors.

### Writing rules (house, mandatory)

- Header: empty date, no z.ai. Keywords below abstract only, no
  categories. ORCID 0009-0005-7399-5584. Co-author cherusk mandatory.
- Agents are agents — not optimizers, not "instruments."
- Simple words; hard sections get wordier, not jargonier.
- Zenodo DOI at submission (wide: Zenodo + HAL; arXiv when endorsed).
  Evidence bundle (curves + sweep.csv + make chain) ships as record
  new-version at submission — this was deferred twice; it ships WITH P3.

---

## PART 2 — HANDOVER: STATE, LANES, RULES

### In flight right now

- **Fair certification runs**: junction-gate seeds 47/48 on the fresh
  stack (33662964012 walking, 33662980408 queued). Done ≈ 19:50Z /
  ≈ 22:00Z. Watchers armed. Verdict script: delta convention, BASE
  1.3375, park 0.30747 (see cliff-v2/j47 analyses in #346).
- **First check on each**: node-4 self-map richness (fair scheduling
  should give 20+ pts; if starved again → the fix didn't hold, escalate
  to cherusk via #346 tag).
- After both: certification table into #346 + P3 results section.

### The interlocked lanes (work semi-parallel, thin slices)

- **Comprehension (cherusk + agent)**: P3 writing — the critical path.
- **Foundation (agent)**: curve-store schema slice — target keys,
  absolute level addresses, epoch segmentation as views. Designed in
  chat Sep 2 (see session-2026-09-02-composition-wave2-fairness.md);
  NOT yet built. Build AFTER P3 draft, per its demands.
- **Evidence (bench)**: idle after certification. Runs serve rungs —
  "point of this?" applies to any new cell.
- **Maintenance**: just-in-time. Lease fairness DONE (0.159.0). Loki
  DONE (2Gi + PVC + retention). Ghosts swept by reinstall. Remaining:
  in-cluster create, trials dump cap, BOM in export, convergence
  detection revival, DoE imports, CFAR calibration — batch later.
- **Consumption**: paused. Unpause trigger: diagnostics demo (scan →
  map with bars → isolation verdict) — buildable on existing receipts,
  per strategic-analysis-notes #4.

### Rulings still pending (cherusk)

- Steering design note go (shard roles + STEER mode + coordinator
  modes #0 + safety port — content sketched in #346 thread + docs).
- Anything else: batch via the open-questions note pattern.

### Rules of engagement (house, learned the hard way)

- Runs serve rungs. One moving part per experiment. One change at a
  time on the bench.
- Store raw truth; views are recomputable. Never delete — scope.
  (Bank was reset Sep 2 by reinstall; ghosts swept; mark-don't-delete
  is the going-forward rule.)
- Label curves by total level. Never by dial. (Cliff-v2's one miss
  proved it in data.)
- Verdict tooling = engine code. Review it like engine code. (Units
  bug scored 1/34 once; BOM broke strict parsing once.)
- Check node-4's self-map FIRST on every junction verdict.
- Tags and reinstalls: cherusk's go. Everything else: within doctrine.
- docs/ is LOCAL ONLY, never committed. Notes are hermes-writable
  directly (chown fixed Sep 2 — no sudo needed anymore).
- Push = x-access-token:TOKEN@git URL (gh helper fails for app tokens).
- Mint token before gh calls (sh /tmp/mint.sh); env GH_TOKEN shadows
  the keychain — use `env -u GH_TOKEN gh ...`.
- SSH: `ssh -i /tmp/openstack_key godon@140.211.166.29`, KUBECONFIG
  /tmp/kind_kubeconfig.yaml. Read-only inspection via
  `kubectl get --raw` service proxy (no tunnels, no backgrounding —
  the tool guard rejects `&`).
- No watchdog scripts (cherusk denied). Use terminal background
  watchers with notify_on_complete.
- Known gotchas: pre-0.158 exports store ABSOLUTE curve values,
  post-0.158 store DELTAS (verdict scripts differ!); export blobs can
  carry BOM-prefixed lines (strip before parse); GitHub caps trial
  dumps at 1000/breeder; Loki had an OOM loop — fixed Sep 2 (2Gi +
  PVC + 7d retention), verify zero restarts if it flaps again.

### The ladder after P3 (named, gated)

1. Steering design note → STEER mode MVP (one tender, one target,
   seven-step loop: predict → act → wait → film → compare → bank →
   revert-if-lied-to).
2. Drift cells: noise-drift (FREE — drift_rate exists in sim.rs, YAML
   only) then structural drift (small sim scheduler) — the M6 referee
   (map half-life ÷ refresh cost).
3. Live-B = steering's final exam. Then phase C (real infra).
4. Atlas/input-typing, variance coupling, scale N≥8 — bench mechanisms,
   cheap, when their rung comes.
5. Stateful tick = the renovation (memory, loops, fixed points).
6. Consumption: diagnostics demo when it's the show; formal track,
   LLM discerner, M6 accumulation — parked.

### Where the session notes live

- This file: the plan + handover.
- session-2026-09-02-composition-wave2-fairness.md: the wave record
  (runs, fixes, laws banked today).
- INDEX.md quick-status updated to PROVEN for composition.
- Stale lines remaining (low priority): essence.md keystone wording,
  engine-status version table (stop at Aug 8).
