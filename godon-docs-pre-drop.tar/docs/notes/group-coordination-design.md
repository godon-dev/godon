# Group-Scoped Coordination — Design

## Problem

The coordination data store is unscoped. Three tables are global singletons:

- `sender_lease` — `CHECK (id = 1)`, exactly one lease for the entire YugaByte
- `detection_readiness` — global barrier, ALL breeders must signal
- `interference_active_breeders` — global heartbeat, ALL breeders counted as neighbors

Consequences:
1. Breeders from different bench scenarios coordinate as if they're coupled.
   A breeder on bench-greenhouse holds params because a breeder on
   bench-microgrid is sending. Garbage data.
2. Deleting breeders leaves coordination state behind. Stale lease holders
   block acquisition. No targeted reset exists.
3. The only reliable reset is `rm -rf /srv/storage/yugabytedb/` — full stack
   reinstall. This is why we restack for every scenario change.

Dead code: `detection_rounds` table methods exist in the controller but are
never called. The coordinator (0.142.0) uses sender_lease exclusively.

## Concept: Group

A group is a coordination scope — the set of breeders that run detection
rounds against each other. The group does NOT declare coupling topology.
It declares the search space: "check for coupling within this set." Coupling
is still discovered empirically by the CFAR detector.

This is the same epistemic status as the probe config: experimental design,
not topology modeling.

### The Group Across Papers 1-3

The group is the container for the entire measurement program:

- Detection (Paper 1, done): "probe within my group to discover edges"
- Characterization (Paper 2): "measure sensitivity coefficients for edges
  within my group" — needs per-parameter perturbation
- Composition (Paper 3): "my group IS the connectome boundary" —
  composition prediction operates within the group

### Group Dynamics — The Central Mechanism

The group is not static. The coupling topology itself is non-stationary —
edges emerge, die, strengthen, weaken. Groups must adapt or go blind.

Lifecycle operations:
- ENTER: new breeder joins (deployed, split from another group, promoted
  from overlap zone, re-probed back in from parked state)
- EXIT: breeder leaves (no coupling found, coupling died)
- PARK: breeder stops coordinating (optimize-only, no holding) but stays
  in metadata. Re-probed on events, not timers.
- MERGE: two groups combine (cross-group edge discovered)
- SPLIT: group divides (internal structure shows independent clusters)

Triggers for dynamics are measurement results:
- Detection: "no edge after N rounds" → candidate for PARK
- Characterization: "coefficient below floor" → candidate for PARK
- Composition: "predicted path doesn't match measured" → missing edge,
  EXPAND search or MERGE groups
- New breeder deployed → re-probe neighbors (including parked ones)
- Configuration change on target → re-probe
- Operator triggers manual rescan

### Anti-Ossification

Three failure modes of frozen groups:
1. NEW coupling emerges between groups — invisible without cross-group probing
2. EXISTING coupling dies — group coordinates around phantom edges
3. COUPLING STRENGTH shifts — membership should change but doesn't

Anti-ossification = periodic cross-group probing + within-group re-verification
of "no edge" pairs. Not full sweeps — single-probe checks. If signal found,
flag for full characterization.

This is the scan-rate vs drift-rate limit (Paper 1) applied to group topology
itself. The coupling topology drifts; the scanning rate determines the fastest
topological change you can catch.

### Parked Breeders

A parked breeder (no coupling found) is not stopped — it optimizes its target.
PARK means: no coordination overhead, no holding for senders. Re-probed on
events (new neighbor deployed, config change, nearby group anomaly).

A parked breeder is also a free passive confounder sensor — it's optimizing,
objectives are recorded, if a sender in a nearby group impulses and the parked
breeder's objective shifts anomalously, that's a cross-group signal at zero
additional cost.

### Dependency: Characterization Data First

The group dynamics — when to split, merge, park, re-probe — need
characterization data to make good decisions. Without it:
- Split decisions are guesses
- Re-probe frequency is arbitrary
- Park vs exit threshold is undefined

Build characterization (Paper 2 per-param resolution) first. Group dynamics
become designable with real data.

## Properties

The group bounds the ROUTINE search space. But cross-group probing is always
possible:

1. WITHIN-GROUP (routine, automatic): full pairwise sweep, all breeders
   participate in turn-taking.
2. ACROSS-GROUP (explicit, deliberate): sender from one group impulses while
   receivers in another hold. One probe answers whether the groups couple.
3. IF COUPLED: targeted characterization of the cross-group edge. Groups
   effectively merged for that pair.

This mirrors how experimental science partitions work: controlled
environments with periodic isolation checks.

### Groups and Characterization

For Paper 2, the group is the measurement context. Per-parameter sensitivity
coefficients are measured within a group. The group defines which breeders
hold still while the sender probes each parameter. Characterization data
feeds back into group structure — uncoupled breeders can be split into
separate groups, strongly coupled breeders stay together.

### Groups and Auto-Sharding

At scale (N breeders), detection is O(N^2) within a group. The discovered
graph should inform the partition. This needs Paper 2 characterization data.
The group_id field is a list-compatible concept (multi-membership for overlap
zones) when this arrives — table structure unchanged.

## Properties

- Breeder carries a group reference at creation time (`group` in config)
- All three coordination tables get a `group_id` column
- Each group has its own lease (one sender per group at a time)
- All queries scope by group_id
- Controller manages group lifecycle: clean on breeder delete, explicit reset
- Multiple groups coexist in the same YugaByte without interference

## Open Questions (Captured, Not Solved)

These emerged during design discussion and are real future needs. They do
NOT block the current fix. They are captured here so the design decisions
don't foreclose them.

### 1. Cross-Group Sender Coordination

Per-group independent senders is the default. But senders in different groups
can interfere with each other through undiscovered coupling. Multiple
strategies exist for handling this:

- IGNORE: independent senders, confounders as noise (default, fine for
  physically separated groups)
- SERIALIZE: global mutex, one sender at a time across all groups. Clean
  attribution, slower. Good for characterization.
- SUBSET SERIALIZE: certain groups coordinate their senders (e.g., shared
  rack), others run free
- DETECT: concurrent senders, detect confounder signal post-hoc in observer

These are policies, not architectural changes. They layer above the per-group
lease. The lease mechanism is the same; the policy decides which senders are
allowed to fire simultaneously.

Additional strategies identified:

- SWITCH-OFF ISOLATION: if cross-talk suspected, selectively disable groups
  one at a time. Group B noise disappears when group A goes quiet? A is the
  confounder. Like switching off breakers to find a short circuit. Diagnostic,
  not continuous.
- SIGNAL/TIMING COORDINATION: senders across groups agree on timing patterns
  (e.g., TDMA: group A sends in even windows, group B in odd). Or a shared
  signal layer where senders announce push windows so the observer can
  attribute perturbations precisely without requiring mutual exclusion.
- MEMBERSHIP ARRANGEMENT: reorganize group membership to isolate suspected
  cross-talkers. Move a boundary breeder into the suspected confounder's group
  for one detection cycle, then restore.

The per-group lease design does not foreclose any of these. All are constraint
or coordination layers on top of the lease, not replacements for it.

### 2. Cross-Group Confounder Detection

If a sender in group A impulses and a breeder in group B shows an unexpected
objective shift, that IS a coupling edge. The artificial boundary didn't
create a false negative — it created a discovery opportunity.

This is an observer/analysis feature, not a coordinator change. The observer
already has all trial data with timestamps. Post-hoc analysis can correlate
group-B objective anomalies with group-A sender windows. When detected, the
edge is flagged for targeted follow-up.

### 3. Auto-Sharding / Group Partitioning

At scale (N breeders), detection is O(N^2) within a group. Manual grouping
works for bench scenarios but not for real deployments. The discovered graph
should inform the partition — uncoupled breeders split apart, coupled groups
merge.

Needs Paper 2 characterization data. The group_id field is a list-compatible
concept (multi-membership) when this arrives — table structure unchanged.

### 4. Group Assignment Evolution

Phase 0 (now, bench): operator sets group manually from scenario config.
Phase 1 (real deployment): auto-assigned from deployment metadata (namespace,
  rack, host, deployment batch).
Phase 2 (adaptive): discovered graph re-shapes groups.
Phase 3 (autonomous): system manages its own partitioning.

What changes across phases is the ASSIGNMENT logic — which lives in the
controller, not in the coordination mechanism.

### 5. Campaign / Policy Layer

A set of groups with shared purpose and policy. "Testing chain4 at three
coupling strengths" = three groups, one campaign. Includes cross-group sender
coordination policy, sharding rules, reporting. Not needed now. Build when
running multiple groups simultaneously reveals what coordination between
groups actually needs.

## What This Does NOT Do (Intentionally)

- No campaign entity (bench scenarios are fine for now)
- No policy engine (per-group independent is the default)
- No auto-sharding (needs discovered graph from Paper 2 data)
- No multi-membership (one group per breeder today)
- No cross-group confounder detection (observer feature, future)

## Why It Won't Be Thrown Away

Every future capability layers ON TOP of group_id:
- Multi-membership: breeder's group_id becomes a list. Column stays.
- Auto-sharding: controller decides assignments. Table structure stays.
- Cross-group sender serialization: policy layer above the lease.
- Campaigns: grouping groups. Tables don't care.
- Confounder detection: observer analysis layer.

## Implementation Scope

Three repos:

### godon-breeders (coordinator + worker)
- `_ensure_tables()`: group_id as primary key on sender_lease, group_id
  column on detection_readiness, migration from old singleton schema
- All lease/readiness/heartbeat queries: scope by group_id
- `_signal_ready()`: include group_id
- `_check_all_ready()`: scope by group_id
- `_count_active_breeders()`: scope by group_id
- `interference_active_breeders`: add group_id column (in worker)
- Breeder worker: pass group_id from config to coordinator

### godon-controller (group lifecycle)
- Breeder creation: read group from config, pass through
- Breeder deletion: clean coordination state for that group
- New operation: reset group coordination state
- Dead code cleanup: remove unused detection_rounds methods

### godon (bench configs)
- All breeder YAML examples get `group: <scenario-name>` field

### godon-charts (workflow)
- Reinstall workflow stays as infrastructure reset
- Bench scenarios can reset group coordination via controller API
