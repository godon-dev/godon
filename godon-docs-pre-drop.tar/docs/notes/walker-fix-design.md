# Walker Fix — Design & Implementation Plan

> Status: APPROVED by cherusk (Sep 4, 2026 session). Docs are LOCAL ONLY —
> never commit this file. Implementation proceeds task-by-task, TDD
> (test-driven-development skill), commits per task on feature branches,
> PRs rebase-merge, co-author mandatory. Reinstall/re-dispatch ONLY on
> cherusk's go after PRs pass.

**Goal:** Make the characterization walk stateless-over-causal ("causal IS
the notebook"): resume exactly across invocations, retire on the complete
curve set (self included) with per-curve bars, and steer to the fattest
priced bracket (the adaptive compass).

**Defects cured:** invocation amnesia (prefix re-walk, seed-48-proven);
self-curve exempt from its own retirement; gaps priced against the primary
listener's bar instead of each curve's own; phantom progress (re-blends
pricing gaps out without coverage); no adaptive steering (geometric ladder +
center tie-break — the P2 mechanism-text gap).

**Verdict semantics (agreed):**
- Two-key retirement unchanged: `converged AND no blocking gap`.
- Blocking gap = `unresolved AND ignorance > bars_sum` — each gap judged
  against its own two endpoint bars (per-gap bar semantics; replaces the
  shared primary-listener `shift_bar`).
- Self-curve enters the verdict enumeration (converged AND, gaps union).
  Primary-receiver selection (reporting: z/delta/TELL marker) stays over
  listeners only — reporting semantics unchanged.
- Coverage contract: deterministic prefix {center, upper, lower} anchors
  pricing; beyond prefix, coverage is certified by price, not promised by
  schedule ("coarse by arithmetic, not sloppy — and it says so in its bars").
- Steering: midpoint of the highest-priced unresolved bracket across ALL
  curves of the walked param (listeners + self). Deterministic tie-breaks:
  wider bracket, then closer to range center, then higher level.
- Depth cap: `refinement_depth` unchanged; refinement level persisted per
  (group, sender, param) in causal (one integer) — explicit storage, not
  inferred from spacing.
- **No silent fallback (cherusk, Sep 4):** an unreachable notebook fails
  the walk invocation loudly — the rigid geometric ladder never runs as a
  failure path. Resume is exact, so a loud failure costs one invocation,
  not the data. The ladder survives only as an explicit
  `walk_policy: ladder` legacy opt-in (offline unit fixtures).

---

## Interface contract (the notebook page)

`GET /walk-view/{sender_id}?param=<name>` →

```json
{
  "sender_id": "...",
  "param": "param_0",
  "refinement_level": 1,
  "curves": [
    {"receiver_id": "uuid|self", "channel": "objective_0",
     "converged": false,
     "levels": [0.0, 50.0, 100.0],
     "gaps": [{"from_level": 0.0, "to_level": 50.0, "jump": 0.51,
               "bars_sum": 0.032, "unresolved": true, "ignorance": 0.255}]}
  ]
}
```

`POST /walk-view/refine` body `{"group_id","sender_id","probe_param"}` →
`{"refinement_level": <n+1>}`.

Steering rule (breeder, pure function of the view):
- No banked levels for the param → prefix: `[center, upper, lower]`.
- Else: candidate brackets = union of unresolved gaps over all curves;
  price = `ignorance`; pick max, tie-break (width, |level−center|, level);
  next level = bracket midpoint. Price ≤ its bars_sum everywhere → `None`
  (param exhausted at current floor → coordinator refine/retire flow).

Blocking rule (breeder, two-key, unchanged shape):
`blocking = [g for g in gaps if g.unresolved and g.ignorance > g.bars_sum]`
— top-level `gaps` from causal now includes self; per-gap bar replaces the
shared `local_bar`.

## Tasks

### Causal — branch `fix/walker-notebook` (godon-images)

- **C1.** Fold self into verdict (main.rs probe_result): after the
  self-banking block, read per-channel `is_converged` + `gaps` for
  (sender, sender, param, ch); extend top-level `gaps` (dedup), AND into
  `converged`; add `self` entry to `receivers_json` (marker never '*').
  Pure helper `fold_self_verdict` + unit test.
- **C2.** `walk_view` handler + registry assembly (pure `assemble_walk_view`
  + unit test on registry fixture).
- **C3.** `curve_store`: `walker_state` table (group, sender, param,
  refinement_level), `load_refinement_level`, `upsert_refinement_level`.
- **C4.** Routes: GET `/walk-view/{sender_id}`, POST `/walk-view/refine`;
  `cargo test` green, `cargo build` clean.

### Breeder — branch `fix/walker-notebook` (godon-breeders)

- **B1.** `engine/walk_policy.py`: `WalkPolicy(causal_url, group_id,
  breeder_id, refinement_depth, transport=None)` — DI transport for tests;
  `next_probe(skip)` (rr over eligible params), `refine()`, `status()`.
  Unit tests: prefix contract; resume exactness; fattest-bracket + tie-breaks;
  priced-out → None; skip honored; depth-cap flow.
- **B2.** probe_coordinator: import WalkPolicy (fallback import path kept);
  `_process_probe_result` per-gap bar; `CHAR PROGRESS` from policy status;
  `_refine_study` → policy.refine().
- **B3.** Seed-48 replay regression: view fixture from the exported curve
  levels; assert walk proceeds past prefix and cannot retire while its own
  knee bracket is unresolved.
- **B4.** Update existing tests (test_probe_coordinator / test_characterization
  mocks: gaps gain `bars_sum`); full `pytest tests/unit -q` green.

### Ship (only on cherusk's go, per step)

- Bump BREEDER_VERSION → charts chore → reinstall (seeder skips scripts —
  clean slate) → s47/s48 re-dispatch.
- Acceptance: node-4 self-map brackets the knee at fine floor; referee
  within-bars; junction rows certify; denial diagnostics clean.

## Quantum rung — FINAL scope (cherusk, Sep 4: accepted as debt)

In scope:
1. `quantum_cycles` config in `interference_detection` (default 3, one-liner:
   at least one ladder step per turn, handoff tax <5%, full rota ≤20 min).
   Yield at probe-cycle boundaries, only when another breeder is
   walk-pending (solo cells run to completion, zero churn).
2. Role-separated ledger: HOLD trials stop consuming the iteration budget —
   followers may not die at cap while waiting (seed-50: 3 of 4 starved).
3. Rota order by remaining priced ignorance (need-weights from causal).

DEBT (accepted): Q as manual config defers the drift-window measurement.
The config value must respect the drift window manually; default 3 is safe
for ≤4 breeders on this bench. Larger groups / real substrates re-open this:
auto-derive Q from a measured drift window W (quiet-run calibration, or
online from drift-event timestamps). Trigger: any scenario with >4 breeders,
or a substrate without an observed stability window.

## Residuals (named, accepted)

- Compass changes level placement → era-label future cross-era comparisons.
- All-equal prices degrade to the geometric order (safe fallback).
- Flat regions stay unprobed by design — their price IS the coverage
  statement (P2's "coarse by arithmetic" made literal).
