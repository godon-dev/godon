# Engine Status

Internal — not published. What's shipped, what works, what's broken, what's
missing. Distilled from session logs (now archived). For the method see
`causal-roadmap.md`; for papers see `paper-status.md`. Read `essence.md` first.

## Deployed versions (as of Sep 2, 2026)

| Component | Version | Notes |
|---|---|---|
| breeder | 0.159.0 | lease fair-share turn counts (walk_pending + acquire_count); parks at neutral; publishes own readings |
| causal | 0.17.0 | self-curves banked (receiver_id=sender), ambient JSONB on curve points |
| observer | 0.70.0 | proxies detection to causal |
| controller | 0.54.0 | group-scoped cleanup, shutdown-first deletion |
| bench-generic | 0.2.0 | cascaded coupling, intake-through doors (nonlinear benches) |
| charts | 0.44.4 | BREEDER_VERSION 0.159.0 |
| charts/godon-observability | 0.4.0 | loki 2Gi + PVC 20Gi + enforced 7d retention (OOM fix) |

Sep 2 additions: nonlinear composition proven (see
session-2026-09-02 notes); lease fairness shipped (#198 — fair-share
turn counts; resolves the sweep-aftermath starvation finding); loki
OOM incident fixed through the chart pipeline (#257). Stack reset
17:32Z + 18:28Z Sep 2 — ghost curves swept, coordination counters
fresh.

All repos on `main`, zero open PRs.

## What works (proven in runs)

- **OTLP → Loki logging pipeline** — fully working; breeder logs with
  structured metadata in Loki (required `SimpleLogRecordProcessor` because
  Windmill runs each flow step as a short-lived subprocess — batch never
  flushes).
- **Coordinator cycling** — push / pause / hold turn-taking with DB-backed
  fencing-token leases. State machine: OPTIMIZE → HOLD_CALIB → IMPULSE_CALIB
  → PUSH → PAUSE → DONE → COOLDOWN.
- **CFAR detection** — proven. Pair test conf=1.0; chain4 all 3 edges.
- **Edge measurement (composition of detection)** — chain4: 3 edges
  (0.7 / 0.5 / 0.3) all measured within ~5-10% of ground truth, 0 false
  positives, topology recovered exactly.
- **Composition (Step 3 — PREDICT)** — PROVEN (Aug 8). Cascaded coupling
  in bench-generic + multi-hop predict in causal + true coupling coefficient
  (sender_delta-based). Linear composition matches within 9% at 3 hops:
  planted 0.105, predicted 0.0956, measured 0.0956. See
  `chain4-composition-results-july31.md` in skill references.
- **bench-generic** — 4 nodes, linear coupling, configurable topology, ground
  truth. Shipped, compiles, GHCR image built.

## Tech debt & blockers (in priority order)

### 1. ~~Coordination table lifecycle~~ — FIXED (Aug 7, 2026)
Group-scoped coordination: per-group leases, auto-cleanup on breeder
deletion, shutdown-flag prevents heartbeat race. Verified with 3 sequential
runs (no restack between them), all coordination tables confirmed empty
after deletion. Design doc: `group-coordination-design.md`.
**Extended Aug 26 (P2 sweep): 12+ consecutive cells on one stack** —
overnight b1-n4 + shape batch, per-cell hygiene only (breeder purge
cascade, target delete, fresh bench container, stale-uuid rm). Restack
now a recovery tool / engine-bump step, not a per-batch cost. Still
unproven: long-lived production breeders, parallel cells, engine bumps
on a live stack.

### 2. Windmill script caching — LIKELY RESOLVED, needs verification
Original symptom: second run loses trial tags (0 push-tagged trials despite
200+ trials). Root cause was unclear. The coordinator rewrite to push/pause
state machine + group-scoped coordination fix (which eliminated stale global
state) likely resolved this. Our 3 sequential runs (Aug 7) showed correct
coordinator cycling in all runs. The seeder's "skip existing" logic means
scripts are only deployed once per restack — but restack nukes Windmill's DB
too, so this is correct behavior. Needs explicit trial-attr verification on
a future run to confirm fully.

### 3. Per-parameter resolution — blocks Paper 2
Currently the coordinator pushes the top-3 parameters to extremes
simultaneously, producing a lumped/blended response — can't attribute the shift
to individual parameters. Need:
- single-param perturbation mode in `IMPULSE_CALIB` (push param_0, then _1,
  then _2, cycling across rounds)
- per-channel detector output: `rising_edge` per (sender_param,
  receiver_objective) pair, not just per objective
- param → channel mapping (bench topology has from_channel/to_channel but
  sender doesn't know which param maps to which channel)

### 4. Scanner cannot distinguish direct from transitive edges
CONFIRMED (Aug 8 chain4 run). Three-hop cascade (A→B→C→D) detected as
a "direct" edge at composed strength (0.0956). Diamond topology test
needed to characterize when transitive coupling creates false direct
edges. Not a bug — a known limitation of pairwise detection.

### 5. Smaller / non-fatal
- `_CachedStorage` shutdown check still broken (non-fatal).
- `HOLD_CALIB` skipped when `hold_params` from config — auto-calibration never
  tested; `MAX_CALIB_STD=0.05` unreachable for non-stationary systems.
- Characterization limited to step amplitude — no full response curve.
- Hardcoded thresholds: `STALE_SENDER_MULTIPLIER`,
  `WORST_CASE_TRIAL_SECONDS`, CFAR `min_cells`.
- bench-generic breeder strain: reconnaissance format assumptions (array
  objective extraction) unverified end-to-end.
- Microgrid bench detection never tested (different channel type —
  approximately linear; same method, untested parameters).

## Scaling — research question, NOT engineering

2-4 agents proven. 50+ is a different regime:
- Full pairwise is O(N²): 50 nodes = 2450 ordered pairs × multiple rounds.
- Turn-taking is serialization by design (one sender at a time).
- The system drifts while scanning — **scan-rate vs drift-rate** is a
  fundamental observability limit, not a bug. "The method supports coupling
  discovery up to drift rate D" is characterization, not failure.
- Needs: parallel probing groups, spatial locality, adaptive scanning,
  hierarchical coordination. None of that exists.
- Needs a **configurable-drift bench** to even test the question — doesn't
  exist yet.

## Technical insights from Aug 7 session

Uncovered during the coordination work + architecture discussion. Not from
prior notes. These inform the direction of future engineering.

### Surprise-driven model growth (generalized algedonic signal)

Beer's algedonic signal routed PAIN to the top of a hierarchy. The
generalization: ANY prediction error — positive, negative, or neutral — is
a signal that the model is incomplete. Objective improved unexpectedly?
Signal. Variance tightened? Signal. Optimization converged to a new region?
Signal.

The complete trigger set is deviation from prediction. Not pain — surprise.
The system hunts for its own ignorance continuously, not just when it breaks.

### Three levels of model growth

Level 1 — same structure, refined coefficients. Re-probing updates the
measurement. The edge is the same, the number is more accurate.

Level 2 — same variables, new edges. Previously undiscovered coupling. A
channel below the noise floor last cycle becomes detectable. A parameter
pair never probed reveals coupling.

Level 3 — new senses. The system discovers it needs to measure something it
was not measuring. A new parameter enters the probe config. A new objective
or observation is added. The model gains a dimension.

Level 3 is the novelty. The system discovers its own blindness and extends
its senses. Active inference updates weights within a fixed model. This
grows the model's structure. Beyond Friston and Beer.

### LLM as event discerner

Two roles in the stack, not one:

Role 1 (already known): campaign and model configurator. Translates human
intent into probe configs. Makes the engine operable.

Role 2 (new): discerner of events from the trenches. Reads prediction
errors, anomalies, surprises. Formulates hypotheses about what's unmodeled.
Designs experiments to extend the connectome. "The shift correlates with
load. Thermal coupling is plausible. The thermal_policy parameter isn't in
the probe config — try that first."

The LLM narrows the search using domain understanding. The impulse protocol
tests the hypothesis. Reality confirms or denies. The LLM is the scientist
that grows the model.

### The empirical model refinement loop

1. PROBE — perturb, measure, update connectome
2. MODEL — build connectome from measurements
3. PREDICT — use connectome to forecast intervention effects
4. ACT — steer system based on predictions (tending)
5. COMPARE — measure actual vs predicted
6. SURPRISE — any mismatch is evidence of unmodeled structure
7. INVESTIGATE — re-probe existing params, try untested params, monitor new
   objectives
8. GROW — connectome gains new edges, new dimensions, new senses
9. REPEAT — model never completes, continuously extends toward the real system

Prediction error drives discovery. Discovery extends the model. Extended
model produces better predictions. Better predictions produce different
surprises. The loop never closes. It converges toward the real system
without reaching it.

### Tending activities are concurrent, not sequential

Today's coordinator is one state machine — one state at a time, one trial
does one thing. Tending needs concurrent activities with different
timescales:

- WATCH: continuous, every trial — check for anomalies, drift, prediction
  failures. Milliseconds.
- PROBE: periodic, every N trials — perturb a parameter to refresh
  connectome. Minutes.
- STEER: reactive, after measurement — adjust params based on connectome.
- HOLD: event-triggered — neighbor probes, freeze immediately.
- PROTECT: priority-triggered — destructive coupling, override everything.
  Interrupts all other activity.
- COLLABORATE: session-based — synchronized action with another agent.

These can't be one state machine. Async coroutines within one agent process
(see Windmill below).

### OPTIMIZE may not survive

The agent doesn't find a point and stop. It maintains a trajectory. The
"optimum" is whatever keeps the coupled system healthy, continuously
updated as conditions change. Optimization folds into STEER.

### Windmill as distributed OS for agent processes

Windmill provides process scheduling, isolation, lifecycle, IPC through
shared DB tables, worker routing, restart on failure. The coordination
tables (sender_lease, interference_active_breeders, detection_readiness)
are IPC primitives. The group is a namespace. The lease is a mutex. The
heartbeat is a liveness signal.

Concurrency: asyncio within scripts. Each agent runs concurrent activities
as coroutines. Cooperative scheduling. The current sequential coordinator
evolves into an async event loop. Stays in Windmill for MVP. Rust service
instances when the latency floor bites.

Migration to Rust when the pattern is settled. Each component ports
independently — causal is already Rust, coordination is SQL, API is JSON.

### Variance coupling — invisible to current detector

CFAR detects coupling when push_median differs from baseline_median. If
coupling is modulatory — A's push doesn't change B's median, it changes
B's VARIANCE — CFAR is blind. A makes B noisier without shifting the mean.
The edge exists. The detector sees nothing.

Fix: add a second detector comparing push-MAD vs baseline-MAD. Same trial
data, new statistic. Small addition. Variance coupling may be the most
important kind for tending — latency jitter, thermal oscillation, power
instability are all variance effects.

## Walker core — classification & generality (Aug 26, observed — not shipped)

The characterization walk's core, stripped of domain: an
ignorance-priced adaptive survey — bisection-style level refinement
where both the refinement criterion and the stopping rule are the
same quantity (priced ignorance = jump × width / range), with
dwell-and-median reads. No model of the curve is fitted; one rule,
and the system's shape decides where effort goes (threshold 15 lv,
weak edges 3 lv, all within bars).

- Output is always a measured influence map (nodes + directed edges
  + bars + gaps) — even self-maps are one-node graphs. The loop is
  substrate-agnostic (any bounded push + noisy read); "edge" is the
  first instance, not the boundary.
- Dual-use confirmed in principle: swap stopping rule (priced-
  ignorance → certified-floor) and the walk is a bar-carrying
  adaptive sampler for metaheuristics; every optimization run could
  leave a certified partial map as a side effect. Hunt-mode stop
  unbuilt.
- BoTorch-class (GP-Bayesian-opt) = closest kin, NOT competitor:
  quiet-room, single-experimenter, optimum-seeking assumptions.
  Our walls they cannot express: contaminated reads (receiver also
  optimizing — protocol, not statistics, is the fix), per-receiver
  attribution, measurement-denominated stopping, certificate vs
  self-reported uncertainty. Potential component (inner sampler
  slot) and downstream consumer (optimize ON the atlas), never a
  rival. Optuna lesson: category anchors win on harness/ecosystem
  around a pluggable algorithm slot, not on novel math.
- Build order unchanged: grid → P2 → P3 → live-B. Sampler mode and
  library shape are later rungs, named so we don't chase them early.



Not blockers for the P2 sweep; the rung ladder after it. Every gap has a
bench mechanism; sizes honest. One architectural keystore: making nodes
stateful/time-stepped (today: pure recompute-on-read, memoryless by
construction). Invariant for ALL extensions: planted truth must stay
closed-form — else it's a simulation, not an instrument calibrator.

| gap | bench mechanism | size | unlocks |
|---|---|---|---|
| nonlinear composition | per-edge transfer f_edge(x) instead of scalar strength; receiver sensitivity level-dependent | small | P3 divergence test (walk must measure curves to predict) |
| variance coupling | noise sigma modulated by upstream level on a designated variance channel | small | second statistic (push-MAD vs baseline-MAD) |
| structural drift | scheduled topology: edge (de)activates at tick N | small | MAINTAIN rescan trigger |
| regime axis | bundle of scheduled changes at tick N (weights flip, edges rewire) | small | atlas-of-regimes |
| dynamics / hysteresis | stateful nodes relaxing per tick (tau per node); branch-dependent targets | medium, one project | EXTRACT: delay, settling, loop gain; recovery fraction becomes measurable |
| live-B resistance | NOT a bench change — breeder mode (receiver keeps optimizing during probes) + optional stiff substrate | engine-side | the honest rung before real substrates |
| scale N>=8 | nothing — bench is N-generic today | YAML only | lease contention, scan-vs-drift economics |

Sequencing: nonlinear-composition bench first (P3 waits), live-B second,
variance coupling cheap/parallel, stateful-tick as its own project, scale on demand.

## Sweep aftermath — two engine findings from the bridge cells (Aug 27)

1. ~~Lease fairness at N≥3 (contention)~~ — FIXED (Sep 2, breeder
   0.159.0 #198): fair-share turn counts (walk_pending +
   acquire_count); acquire denied while a walk-pending peer has fewer
   turns. Before-receipt: junction seed 47 (n4 self-map starved to
   3 pts, 2 referee misses localized to the coarse region — #346).
   Fair-scheduled certification reruns follow the Sep 2 reinstall.
2. **First-hold transient, three receipts (e3 pk1.02 on unplanted
   path; e6 26-level flat-then-jump; diamond param_0 oddity):**
   receiver init (params 0→50 at first hold) recorded as structure
   on in-flight sender curves. cherusk's parked seed-at-hold call
   is now P3-prerequisite grade, not cosmetic.

P2's 24 within-bars rows unaffected (all N=2). Runner harness
lessons: token auto-re-mint on 401; data-over-badge verdicts;
wedged-run re-dispatch recovery.

## Access (operational)

- SSH: `ssh -i openstack godon@140.211.166.29` (OSUOSL)
- KUBECONFIG: `/tmp/kind_kubeconfig.yaml`
- GitHub token: `/tmp/gh_token.txt` (regenerate via get_token.py)
- Paper: `papers/detection/paper/main.pdf`
- Sweep data: `papers/detection/experiments/` (21 cells)
- Coordination lifecycle design:
  `papers/detection/experiments/notes-coordination-lifecycle.md`
