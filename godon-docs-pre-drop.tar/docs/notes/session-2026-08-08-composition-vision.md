# Session — Aug 8, 2026: Composition Validated + Design Discoveries + Vision

## SHIPPED THIS SESSION

### Composition test PASSED (linear, 3 hops)

Two code changes enabled the test:

1. **bench-generic cascaded coupling** (sim.rs, v0.2.0, PR #268):
   `recompute_objectives()` used source node BASE values for coupling,
   breaking signal propagation beyond one hop. Chain topologies
   (A→B→C→D) only propagated A's perturbation to B; C and D saw nothing.
   Replaced with iterative relaxation (Jacobi). Each node computes its
   coupled value from neighbors' COUPLED values (not base). N-1 passes
   propagate through any DAG; convergence check exits early.

2. **causal multi-hop predict + true coupling coefficient** (v0.4.0, PR #269):
   - `predict_multihop()`: BFS through detected edges composing
     sensitivities multiplicatively along paths. New endpoint
     `POST /predict/multihop`. Returns predictions for all reachable
     nodes with paths and composed confidence.
   - Sensitivity formula changed from `rising_edge / impulse_scale`
     (parameter push magnitude) to `rising_edge / sender_delta`
     (sender's actual objective shift). The old formula conflated the
     base function with edge strength — off by ~2x for linear. The
     true coefficient composes correctly.
   - 6 unit tests (CI-enforced via Nix `doCheck=true`). Chain4 math
     verified against planted ground truth.

3. **Idempotent breeder creation** (PR #304): port-forward flakiness
   (127.0.0.3) caused create requests to succeed but responses to be
   lost. Retries created ghost breeders. Fixed: check for existing
   breeder by name BEFORE each create attempt.

### Result

```
Planted:     0.7 × 0.5 × 0.3 = 0.1050
Predicted:   0.0956  (composed from edges via /predict/multihop)
Measured:    0.0956  (detected at node-4 as transitive edge)
Error:       9%
```

Per-hop accuracy:
- node-2: 0.6900 vs 0.7   (1.4% error)
- node-3: 0.3438 vs 0.35  (1.8% error)
- node-4: 0.0956 vs 0.105 (9.0% error)

Breeder-to-node mapping (clean run, 4 breeders, no ghosts):
- bench-chain4-1 (badceb1b) → node-1
- bench-chain4-2 (aa9cfab7) → node-2
- bench-chain4-3 (1d3fe41a) → node-3
- bench-chain4-4 (72dd41dd) → node-4

### PRs merged
- #268 godon-images: bench-generic cascaded coupling
- #269 godon-images: causal multihop predict + true coefficient + tests
- #303 godon: bump bench-generic image to 0.2.0
- #304 godon: idempotent breeder creation
- #233 godon-charts: bump causal 0.4.0

### Deployed versions
| Component | Version |
|---|---|
| breeder | 0.144.0 |
| causal | 0.4.0 |
| observer | 0.70.0 |
| controller | 0.53.0 |
| bench-generic | 0.2.0 |

---

## DESIGN DISCOVERIES (from post-experiment discussion)

### D1: The detector wastes system-level structure

The detector processes pairs in isolation. During one sender's push, ALL
group members hold and record. The detector loads all their trials — it
has the full response vector — then decomposes it into independent
pairwise measurements, throwing away the joint structure.

The simultaneous response vector (B=0.7, C=0.35, D=0.105) is a topology
fingerprint. More information than three independent pairwise measurements,
because all receivers experience the SAME noise realization during one
push.

### D2: Linear topology is matrix inversion

For linear systems, the full response matrix M = (I-W)^{-1}, where W is
the direct edge matrix. So W = I - M^{-1}. The detector collects the full
response matrix every run — it just never inverts.

Transitive edges become zero in W. Direct edges remain. Exact for linear.
The detector has the data; it lacks the computation.

### D3: Response curves per edge are the universal foundation

Not scalars — FUNCTIONS. Sweep A's push at multiple levels (0.125, 0.25,
0.5, 1.0), measure D's response at each. The curve:
- Tells you if the edge is linear (straight line) or nonlinear (curved)
- Determines which topology method is valid
- Feeds iterative forward simulation for composition
- IS the characterization (no separate phase)
- Carries topology information through shape distortion

### D4: IMPULSE_CALB already collects multi-point data

The coordinator backs off 1.0 → 0.5 → 0.25 → 0.125 during calibration.
That 4-point data is currently thrown away. It's a free 4-point response
curve per edge if kept.

### D5: Iterative forward simulation is the ONE universal method

Response curves + iterative forward simulation (Gauss-Seidel):
- Linear: converges immediately (one step)
- Nonlinear: converges in more iterations
- Cycles with gain < 1: converges (dynamics visible in iteration trace)
- Cycles with gain approaching 1: converges slowly — warns of instability
- Cycles with gain > 1: diverges — screams

No special casing. One method subsumes composition, prediction, feedback
dynamics, instability detection. The July 24 notes had this right.

### D6: The trial notion is breaking

Trials are Optuna optimization primitives: suggest params → effectuate →
measure objective → report value. Characterization needs richer data —
time series within a push, operating point metadata, ground-truth
measurements from multiple agents. Needs its own data model.

Proposed: structured characterization table in archive_db. Fields like
sender_id, receiver_id, round_id, measured_shift, onset_offset,
settling_samples, sender_operating_point, receiver_operating_point.

### D7: Collaborative characterization — agents sharing ground truth

Each breeder knows its own state exactly — its real-time objective value,
its noise characteristics, its operating point. The causal service sees
only trial-level medians. A breeder reporting "I shifted 0.352" from
ground truth is categorically more precise than the causal service
estimating 0.35 ± 0.02 from CFAR detection.

This is NOT the same as sharing trial data (which the causal service
already has). It's sharing INTERNAL STATE that the causal service never
sees. The precision profile is fundamentally different.

### D8: The additive bench is degenerate for characterization

Active cancellation, multi-sender experiments, operating-point modulation
— all fail for additive linear coupling because superposition makes the
relay channel transparent. B changing its params doesn't modulate A's
transit through B.

For multiplicative coupling (thermal, electrical — real systems), all
these techniques work. The bench should eventually support multiplicative
coupling for realism.

### D9: Two-phase architecture — discover then characterize

Phase 1: crude CFAR detection finds candidate edges. Robust, universal,
no prior knowledge needed.

Phase 2: coupled agents run targeted characterization experiments. They
know their relationship. They use their optimization capabilities and
ground truth to build response curves, resolve topology, characterize
dynamics. Different instrument, different precision.

This connects to L3 from causal-session-architecture: "The metaheuristic
should serve measurement — exploring the space, generating perturbation
data from which coupling is discovered."

---

## DEAD ENDS (explored and rejected)

### DE1: Watermarks / sender-specific signatures
Rejected. Painful history — reconstruction fidelity problem, regression
to the watermark era. cherusk: "I would really like to avoid any signal
signature or sender specific watermark."

### DE2: Delay-based topology alone
Insufficient. Delay confounded by node response dynamics, not pure path
length. Useful as one input but not enough alone. Needs bench dynamics
that don't exist.

### DE3: Pure information sharing without ground truth
No gain over centralized analysis. Same data, same limits. The gain
comes from ground truth the agents have that the causal service doesn't.

### DE4: Multi-sender experiments for linear
Superposition kills all interaction terms. Dead end for linear.
Works for nonlinear.

### DE5: Active cancellation for additive coupling
B changing params doesn't modulate A's transit through B in additive
coupling. Dead end for current bench. Works for multiplicative.

---

## VISION — THE DRAGON

### The coupling graph is the dragon's anatomy

Every coupled system is a leviathan — a dragon sleeping in our
infrastructure. Power grids. Chemical plants. Data centers. Fusion
plasmas. Chip fabs. We built them. We feed them. We can't see inside
them. We fear them blindly.

The impulse protocol makes the dragon visible. The coupling graph lights
up — ethereal, luminous threads connecting nodes through invisible
channels. The feedback loops reveal themselves. The dangerous
gain-approaching-1 paths glow red.

### Seeing is the end of the leviathan

The leviathan doesn't end by force. It ends by SEEING. Once seen, it's
not a leviathan anymore — it's a measured system with known edges, known
feedback loops, known pressure points. Still powerful. Still dangerous.
But no longer invisible.

"The end to the leviathan starts by seeing them."

### Coupling AND feedback — the two blind spots

Layer 1: COUPLING — see where the hidden threads are, how strong, through
what channels. The first sight.

Layer 2: FEEDBACK — see which threads loop back, at what gain, creating
dynamics. The graph with cycles is a dynamical system model, not a
snapshot. It predicts not just what IS coupled but how the system EVOLVES.

Iterative forward simulation on the cyclic graph IS the dynamics
computation. Loop gain determines convergence. The same method that
composes edges for prediction also reveals feedback dynamics.

### The software-to-physics seam

The practical gap: control software assumes fixed coupling. Physical
systems drift. The connectome measures the real coupling continuously
and feeds it back into the control system. The infrastructure retunes
itself.

Examples:
- Chemical plants: operators' coupling knowledge dies when they retire
- Chip fabs: 6-18 month yield ramps are trial-and-error characterization
  of cross-step coupling
- Power grids: cascading blackouts from unmeasured coupling paths

### The connectome WITH a neural layer

Measured graph as ground-truth backbone (explicit, certifiable,
transferable). Neural approximation fills between scans (fast, adaptive,
always running). Prediction error between the two drives new probes.
Two layers co-evolve.

The system investigates ITSELF. Probes, measures its own structure,
predicts, fails, re-probes where wrong. Model grows toward the real
system through prediction error gradients.

This mirrors the three-peer model: limited AI runs fast approximation,
impulse protocol provides ground truth, human reads the explicit graph.

### Prince of Dragons

The one who doesn't slay, doesn't flee, doesn't pretend the dragon
isn't there. The one who learns its coupling, steers around its
pressure points, keeps it calm by working WITH its structure instead
of against it.

The dragons were always here. We built them. We fed them. We feared
them. Now we can see them.

---

## OPEN QUESTIONS

- Topology for nonlinear instant-coupling: response curve shape helps
  but unproven. Needs nonlinear bench.
- Should bench support multiplicative coupling for realism?
- Collaborative characterization data model — new table? How do
  breeders write richer observations during hold?
- When does detector switch from pairwise CFAR to group-level analysis?
- Active subspace identification for high-dimensional edges (causal-
  roadmap already proposed this — needs implementation)

## NEXT STEPS — phased roadmap

### Phase 1: Characterization foundation (BLOCKING — unblocks everything)

1a. **Keep IMPULSE_CALIB multi-point data.**
    The coordinator backs off 1.0→0.5→0.25→0.125. Currently only the
    locked amplitude survives. Each level's push/pause data should be
    tagged with impulse_scale and preserved for response curve fitting.
    Files: breeder_worker.py (trial tagging), detector.rs (per-scale
    output).

1b. **Per-parameter perturbation mode.**
    Currently coordinator pushes top-3 params simultaneously (lumped
    stimulus). Need single-param IMPULSE_CALIB: push param_0, then _1,
    then _2, cycling across rounds. Per-channel detector output:
    rising_edge per (sender_param, receiver_objective) pair.
    Files: detection_coordinator.py (IMPULSE_CALIB state), detector.rs
    (per-param-per-channel detection), bench-generic sim.rs (param→channel
    mapping needed).

1c. **Characterization data model.**
    Stop forcing characterization through Optuna trials. New table in
    archive_db: sender_id, receiver_id, round_id, sender_param, push_level,
    measured_shift, onset_offset, settling_samples, sender_operating_point,
    receiver_operating_point, sender_noise_sigma, receiver_noise_sigma.
    Characterizer writes this; causal service reads it instead of
    reconstructing from trial medians.

1d. **Response curve fitting in characterizer.rs.**
    Replace single-sensitivity StepResponse with a ResponseCurve enum:
    Linear { slope }, Polynomial { coeffs }, Saturated { k }, etc.
    Fit from multi-point data. The curve type IS the linearity classification.

### Phase 2: Detector upgrades

2a. **Group-level analysis.** For each push round, analyze ALL group
    receivers' response vector jointly. Not independent pairs. The
    simultaneous measurement has structure that pairwise discards.
    Files: main.rs build_graph_inner (restructure the pair loop).

2b. **Variance coupling detector.** Same trial data, compare push-MAD
    vs baseline-MAD instead of push-median vs baseline-median. Second
    detector behind the EdgeDetector trait.
    Files: detector.rs (new CfarVarianceDetector).

2c. **Linear topology via matrix inversion.** Build response matrix M
    from all single-sender experiments. Compute W = I - M^{-1}. Direct
    edges: nonzero in W. Transitive: zero. Trivial for linear.
    Files: graph.rs (new method), main.rs (new endpoint /topology).

### Phase 3: Composition validation

3a. **Diamond topology bench.** A→B, A→C, B→D, C→D, no A→D. Tests
    whether scanner reports transitive A→D. New scenario config.

3b. **Iterative forward simulation in causal.** Generalize predict_multihop
    from scalar multiplication to response-curve propagation. For each
    node: apply incoming edge functions to current state, update, iterate
    until convergence. Gauss-Seidel. Handles nonlinear and cycles.
    Files: graph.rs (new propagate method), main.rs (new endpoint).

3c. **The closed-loop test (THE GATE).** Two coupled breeders. Discover
    edge. Act on it (adjust params using connectome to avoid coupling
    damage). Measure whether joint outcome improves vs blind optimization.
    Depends on: Phase 1 (characterization usable), Phase 3b (prediction
    working). Cheapest experiment, highest value.

### Phase 4: Paper work

4a. Paper 2 (characterization): the sweep IS the paper. 21 cells exist.
    Needs per-parameter data (1b) and response curves (1d).

4b. Paper 3 (composition): linear validated tonight. Needs nonlinear
    divergence (response curves on nonlinear bench) and diamond topology
    (3a) for transitive edge limitation.

### Dependency order
Phase 1 → Phase 2 (can partially parallelize) → Phase 3 → Phase 4
The closed-loop test (3c) can start as soon as Phase 1 is usable.

### Visual assets (when engineering catches up)
- Engine schematic (stacked, da Vinci codex style) for docs/README —
  only after characterization exists. All 8 layers must be real.
- Dragon triptych (awakening, steering, wrestling) for landing page /
  talks — ready when there's something to show publicly.
- Image prompts saved at: /tmp/dragon-vision-prompt.txt,
  /tmp/cherusk-steering-infra-prompt.txt,
  /tmp/cherusk-group-summoning-leviathan-prompt.txt,
  /tmp/engine-loop-prompt.txt, /tmp/engine-stacked-genetic-prompt.txt

---

## ADDITIONAL DISCOVERIES (post-session-notes discussion)

### A1: Linear topology = matrix inversion
M = (I-W)^{-1}, so W = I - M^{-1}. The detector collects the full
response matrix every run but never inverts. For linear systems this
gives EXACT direct edge separation — transitive edges become zero.

### A2: Iterative forward simulation subsumes ALL cases
Linear converges in one step. Nonlinear converges in more. Cycles
reveal dynamics — loop gain determines convergence behavior. Divergence
warns of instability. One method, no special casing. The July 24
notes had this right (Gauss-Seidel).

### A3: Response curve linearity test selects the method
Sweep at multiple push levels. Straight line → linear → inversion or
fast iteration. Curved → nonlinear → more iterations needed. The curve
IS the characterization AND the method selector.

### A4: IMPULSE_CALB multi-point data is free response curves
The coordinator already backs off 1.0 → 0.5 → 0.25 → 0.125. That
4-point data is currently discarded. Free response curve per edge.

### A5: Unmeasured coupling caps achievable complexity
We design systems modular and simplified not because it's optimal but
because we can't reason about coupled structure. Measure coupling →
unlock complexity. New classes of systems become buildable — too
coupled for human intuition, manageable through measured graphs.

### A6: Intervention vs observation — different instrument category
Every existing instrument observes passively (thermometer, profiler,
oscilloscope). The impulse protocol INTERVENES — the measurement
creates the signal. The coupling doesn't exist as observable data
without the perturbation. This is a new instrument category that
Ashby described philosophically in 1956 but couldn't build. The
detection engine is the first implementation.

### A7: Coupling/interference is too small a word
The relationships ARE the system. Components are where relationships
converge. The system unfolds through measurement of its interactions.
"Coupling discovery" frames it as connections between known things.
It's actually: structural revelation of a whole that exists only in
relationships and cannot be derived from parts.

### A8: Structural knowledge is dual-use
Same coupling graph that enables safe steering also reveals where to
cut for maximum cascade. Taming vs weaponizing is a human choice, not
a technical property. The map doesn't care about intent.

### A9: Steering is continuous engagement, not configuration
The graph goes stale as the system drifts. Stop measuring and you're
blind again. Steering is a loop — measure, act, measure mismatch,
correct. "Wrestling on par" — never above the system, never done.

### A10: The OS as ultimate test case
Map and hold an operating system from top to bottom. Thousands of
coupled components, feedback loops, emergent behavior. Nobody has
ever seen the full behavioral structure. May require entirely new OS
architecture designed for self-measurement — components that expose
response curves, participate in continuous characterization, steer
through measured relationships instead of hardcoded assumptions.

### A11: Management as the dragon's ally
The leviathan doesn't just survive despite management — it is FED by
them. Every "integration" project adds coupling. Every "synergy"
initiative weaves new threads. Every cost cut removes decoupling
buffers. The people who fund infrastructure are the dragon's biggest
allies — not by malice, by ignorance of coupling. "Digital
transformation" = more threads for the dragon. The instrument that
would prevent it is a perturbation and a measurement — but nobody
knows to ask.
