# Session Notes — Sep 3, 2026: cert-47 extended rerun, thin self-map → bug

## Run

- **cert-47 fair + extended clock (33720423947, breeder 0.160.0):**
  completed success, 05:50–09:53Z ≈ 4h05m (extension applied; baseline ~2h).
- Watcher (GH-API-only, /tmp/watch_run.py) fired 09:53Z success.

## Verdict (junction gate, delta convention park 0.30747)

- Pieces rich: F12 42 / F13 42 / direct N1→N4 42 pts.
- Node-4 self-map: **3 pts — fourth occurrence** (starved, fair, fair+2x clock).
- Gate: **25 ok / 17 miss**; misses = 3-pt-chord region + one wild L=50 read
  (−0.309 ≈ off-park signature).
- Physics fine: direct tracks planted deltas (L=0: 0.0265 vs 0.0259);
  where the chord is sane (L≥52): 19/20 within 2σ.
- Junction certification row stays seed 46. **cert-48 rerun ON HOLD.**

## The bug (user's call, code confirms the shape)

An UNCONVERGED walk (conv=False throughout) with eligible coverage moves
(25/75 within floor reach) and an unresolved gap (0↔50: jump 0.122 >
bars_sum 0.029) stopped at 3 points. Walk logic doesn't do that alone —
external stop. Classes: (a) budget/priority — clock extension ≠ turn share,
source pieces grew 31→42; (b) fair-share accounting edge (newcomer/twins).
Distinguisher: node-4 Loki flow log — last probe near 09:53Z (stall) vs
hours earlier (starved). Awaiting go.

Two wrong turns retracted on the way (logged so they stay dead):
- end-of-run tell (z=1.000) is the FIRST-PROBE NEUTRAL (probe_curves.rs:262),
  not a walk verdict — "best-effort exit" was built on it;
- "stopping rule blind to curvature" — premature: no stopping rule fired.

The 3 pts themselves are honest: 3/3 within ~1 bar of the planted map.

## Posted

- #348 update: …/issues/348#issuecomment-5525036733
- #346 verdict: …/issues/346#issuecomment-5525036859

## Morning aside — "why no curves mid-run"

First mid-run /curves poll in project history (all past numbers came from
end-of-run exports) — no baseline existed; run was healthy, just slow to
first level-close. Don't mid-run-polled without a baseline again.

## Open

- PATCHED same day: fix drafted as godon-breeders#200 (draft PR, CI green,
  320 unit tests) — demand=False on walk completion + denial diagnostics.
  Awaiting cherusk review/merge go → chart bump → reinstall → cert reruns
  s47/s48 → certification rows. #348 fix pointer:
  …/issues/348#issuecomment-5525891334
- cert-48 rerun: hold until reruns land clean.
- Verdict script: /tmp/verdict_junction2.py now delta-correct (−0.30747).
